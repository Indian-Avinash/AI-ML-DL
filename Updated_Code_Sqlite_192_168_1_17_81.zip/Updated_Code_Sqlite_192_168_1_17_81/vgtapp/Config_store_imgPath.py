import base64
import cv2
import numpy as np
import os
from datetime import datetime

def store_GifPath(GifData):
    if os.path.exists("GIFs"):
        print("GIFs folder already created!")
    else:    
        os.mkdir("GIFs")
    # print(type(GifData))
    if GifData.name != "string":
        name = GifData.name
    else:
        name = "GIF"
    # print(GifData.name)
    # Decode the base64 string back to binary data
    gif_data = base64.b64decode(GifData.GIFstring)

    # Generate the file name with the current timestamp
    current_time = datetime.now().strftime("%Y_%m_%d_%H_%M%S")
    imagePath = f"GIFs\{name}_{current_time}.gif"
    # imagePath = f"GIFs\{name}_{current_time}.mp4" 

    # Save the binary data as a GIF file in the specified folder path
    with open(imagePath, 'wb') as file:
        file.write(gif_data)
    # print("DONE!")
    return imagePath


def store_GifPath_VGT(GifData,incident):
    if os.path.exists("GIFs"):
        print("Images folder already created!")
    else:    
        os.mkdir("GIFs")
    # print(type(GifData))
    if GifData != "string":
        name = GifData
    else:
        name = "GIF"
    
    # Decode the base64 string back to binary data
    gif_data = base64.b64decode(GifData)

    # Generate the file name with the current timestamp
    current_time = datetime.now().strftime("%Y_%m_%d_%H_%M%S")
    imagePath = f"GIFs\{incident}_{current_time}.png"
    # imagePath = f"GIFs\{name}_{current_time}.mp4" 

    # Save the binary data as a GIF file in the specified folder path
    with open(imagePath, 'wb') as file:
        file.write(gif_data)
    print("DONE!")
    return imagePath