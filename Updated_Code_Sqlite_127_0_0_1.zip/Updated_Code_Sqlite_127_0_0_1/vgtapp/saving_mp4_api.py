import os
from fastapi import Request
import cv2
import time
from datetime import datetime
from pymongo import MongoClient
from urllib.parse import urlparse
from vgtapp.models import Saving_mp4_DB


import os

def convert_avi_to_mp4(avi_file_path, output_name):
    os.popen('ffmpeg -i {input} -strict -2 {output}'.format(input = avi_file_path, output = output_name))
    return True


def capture_mp4(rtsp_lisk,admin_id,user_name,user_id,site_name,camera_name,Route_name):

    '''
    This function takes the rtsp link captures the frames and saves the 15 seconds video
    in the local and saves the path in the database.
    '''

    # Set the desired smaller frame size
    smaller_frame_width = 640
    smaller_frame_height = 480

    try:
        #started capturing the frames using videocapture function
        cap = cv2.VideoCapture(rtsp_lisk)
        #*'H264' (MP4) #codec codes
        #*'XVID' (AVI)
        #*'MP4V'  (MP4)
        #*'X264' (MP4)
        #*'AVC1' (MP4)
        count = 0 #for counting the frames declared the count variable
        fourcc = cv2.VideoWriter_fourcc(*'XVID') #declaring fourcc with codec H264
        recording = False #recording variable used to check if the recording should start or not.
        #fourcc = cv2.cv.CV_FOURCC(*'H264')
        #print("The fourcc code is:",fourcc)
        #if frames are open start capturing.
        while cap.isOpened():
            '''
            Start reading the frames.
            '''
            res,frame = cap.read()
            if not res:
                '''
                if frames are not captured restart the capturing.
                '''
                cap = cv2.VideoCapture(rtsp_lisk)
                continue
            frame = cv2.resize(frame,(640,480))

            if not recording:
                date = datetime.now().strftime("%d_%m_%Y_%H_%M_%S")
                todays_date = datetime.now().strftime("%d_%m_%Y")
                video_path = f"C:/Users/KFT_1069/Downloads/Updated_Code_Sqlite_old_version/video/{date}"
                os.makedirs(f"{video_path}",exist_ok=True)
                # os.mkdir("C:/Users/KFT_1069/OneDrive - KNOWLEDGEFLEX TECHNOLOGIES PVT LTD/Desktop/VGT_Updated_03_04_2024_To_be_hosted_on_server/VGT_API/video")
                # os.chdir("C:/Users/KFT_1069/OneDrive - KNOWLEDGEFLEX TECHNOLOGIES PVT LTD/Desktop/VGT_Updated_03_04_2024_To_be_hosted_on_server/VGT_API/video")
                # os.chdir("/var/tmp/")
                AVI_video_path = f"{date}.avi"
                Mp4_video_path = f"{date}.mp4"

                out = cv2.VideoWriter(AVI_video_path,fourcc,20.0,(smaller_frame_width,smaller_frame_height))
                recording = True



            if recording:
                out.write(frame)
                count +=1
                #convert_avi_to_mp4(AVI_video_path,Mp4_video_path)
                if count > 300:
                    #480 is the microseconds for the given 15 seconds
                    recording = False
                    out.release()
                    count = 0
                    doc={   
                            "rtsp_link" : rtsp_lisk,
                            "admin_id" : admin_id ,
                            "admin_id" : admin_id ,
                            "user_name": user_name,
                            "user_id"  : user_id ,
                            "image_path": Mp4_video_path,
                            "site_name":site_name,
                            "camera_name" : camera_name,
                            "Route_Name" : Route_name,
                            "Datetime" : todays_date
                        }
                    saved_data = Saving_mp4_DB.objects.create(
                            rtsp_link  = doc["rtsp_link"],
                            admin_id  = doc["admin_id"] ,
                            user_name = doc["user_name"] ,
                            user_id   = doc["user_id"] ,
                            image_path = doc["image_path"] ,
                            site_name = doc["site_name"] ,
                            camera_name  = doc["camera_name"] ,
                            Route_Name  = doc["Route_Name"] ,
                            Datetime  = doc["Datetime"] 
                    )
                    cap.release()
                    saved_data.save()
                    cv2.destroyAllWindows()
                    convert_avi_to_mp4(AVI_video_path,Mp4_video_path)
                    break
    except Exception as e:
        return e

# ffmpeg -i input.avi -strict -2 output.mp4

