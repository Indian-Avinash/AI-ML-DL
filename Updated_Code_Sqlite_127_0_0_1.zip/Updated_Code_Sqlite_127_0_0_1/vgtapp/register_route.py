import pymongo
from datetime import datetime
from vgtapp.models import Route_Management
import json 


mycol = Route_Management
saved_route_list = []

def route_info(data):
    r_n = data["Route_Name"]
    for routes in mycol.objects.all():
        saved_route_list.append(routes.Route_Name)
    
    if r_n in saved_route_list:
        status = { "Status" : "500",
            "Message":"Data Already Present!"}
    else:
        s_n = data["Site_Name"]
        admin_id = data["Admin_userid"]
        info = {
            "Route_Name": r_n,
            "Site_Name": s_n,
            "admin_id": admin_id,
            "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
        }
        # mycol.objects.create(info)
        route_data = mycol.objects.create(
            Route_Name = info["Route_Name"],  
            Site_Name = info["Site_Name"],  
            admin_id = info["admin_id"],
            DateOfCameraRegistration = info["DateOfCameraRegistration"]  
        )
        route_data.save()
        
        status = {"Status":"200","Message":"Success"}
    return status
