import pymongo
from datetime import datetime,timedelta


def get_countof_events(Start_Date,End_Date):
    # Connect to MongoDB
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    db = client["Guard_Patrol"]
    count_of_dictionary_answers_checklist = []
    storage_of_userids = []
    storing_cameras_in_list = []
    count_Of_answered_question = ""
    
    # Collections
    user_database = db["user_management"]
    report_collection = db["Report_for_particular_sitename"]
    mapped_route_collection = db["Mapped_Route_Management"]
    answered_collection = db["Storing_Answers_To_Checklist"]
    


    for route_docs in mapped_route_collection.find({}):
        admin_id = route_docs["Admin_UserID"]
        site_name = route_docs["Site_Name"]
        Route_name = route_docs["Route_Name"]
        date_of_registration = route_docs["DateOfCameraRegistration_Dateformat"]
        
        start_date_list = Start_Date.split("/")
        start_day,start_month,start_year =int(start_date_list[0]),int(start_date_list[1]),int(start_date_list[2])
        
        End_date_list = End_Date.split("/")
        End_day,End_month,End_year =int(End_date_list[0]),int(End_date_list[1]),int(End_date_list[2])
        
        # Define start and end dates   
        start_date = datetime(start_year, start_month, start_day)
        end_date = datetime(End_year, End_month, End_day)

        date_difference = end_date - start_date
        # Generate a list of dates within the range
        date_list = [(start_date + timedelta(days=x)).strftime("%d/%m/%Y") for x in range(date_difference.days + 1)]

        result_list = []
        for dictionarys in mapped_route_collection.find({"Admin_UserID": admin_id,"Site_Name":site_name,"Route_Name":Route_name,"DateOfCameraRegistration_Dateformat":date_of_registration}):
            storing_cameras_in_list.append(dictionarys["Camera_Name"])
        number_of_task_count = len(storing_cameras_in_list[0])
        
        
        report_docs = report_collection.find_one({"admin_Id": admin_id,"Site_Name":site_name,"Route_Name":Route_name,"Date_Of_CameraRegistration": date_of_registration})

        count_Of_answered_question = answered_collection.count_documents({"Admin_id":int(admin_id),
                                                # "Site_Name":site_name,
                                                "Registered_Camera_Answer_Response": date_of_registration,
                                                "Route_Name" :Route_name})
        
        if report_docs:     
            for dates in date_list:
                date_of_registration = dates

                for userid in storage_of_userids:
                    
                    count_Of_answered_question = answered_collection.count_documents({"Admin_UserID":int(admin_id),
                                                                                    #   "Site_Name":site_name,
                                                                                    "Registered_Camera_Answer_Response": date_of_registration,
                                                                                    "Route_Name" :Route_name})
                report_collection.update_one(
                    {"admin_Id":admin_id,"Route_Name":Route_name,"Date_Of_CameraRegistration":date_of_registration},
                    {"$set": {"Number_Of_Tasks": number_of_task_count,
                            "Answered_Questions": count_Of_answered_question}}
                ) 
                report_docs = report_collection.find({"admin_Id": admin_id, "Route_Name":Route_name})
                # for docss in report_docs:
                    # print(f"{admin_id}_{docss}")
            storing_cameras_in_list.clear()
        else:
            for user_ids in storage_of_userids:
                count_Of_answered_question = answered_collection.count_documents({"Admin_id":str(user_ids),
                                                            "Registered_Camera_Answer_Response": date_of_registration,
                                                            "Route_Name" :Route_name})
            report_collection.insert_one({
                "admin_Id": admin_id,
                "Site_Name": route_docs["Site_Name"],
                "Route_Name": route_docs["Route_Name"],
                "Number_Of_Tasks": len(route_docs["Camera_Name"]),
                "Answered_Questions": count_Of_answered_question,
                "Date_Of_CameraRegistration": date_of_registration
            })
        storage_of_userids.clear()
        result_list_of_dict = []
    
    for docs in report_collection.find({},{"_id":0}):
        result_list_of_dict.append(docs)

    count_of_dictionary_answers_checklist = []
    return result_list_of_dict
