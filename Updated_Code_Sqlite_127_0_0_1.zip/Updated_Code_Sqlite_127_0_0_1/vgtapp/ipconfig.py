import subprocess
import os

def get_ipconfig():
    list_of_address = []
    ip_address = ""
    output = subprocess.check_output(['ipconfig', '/all'])
    output = output.decode('utf-8')
    lines = output.splitlines()
    # print("The lines :",lines)
    for line in lines:
        line_one = line.replace(" ","")
        if "IPv4Address" in line_one:
            print("The ip address",line_one)
            list_of_address.append(line_one)
    final_result = list_of_address[1].split(':')[1].strip() # spliting the word at :
    ip_address = final_result.split("(")[0]
    print("The ip address:",final_result,ip_address)
    return ip_address

