import smtplib
import random
import pymongo
from pymongo import MongoClient #mongo and db
from email.message import EmailMessage #Basic message object for the email package object model.

from vgtapp.models import *
mycol = admin 
stored_email = []


def email_alert(emaildata,email_name):
    
    """_summary_
    Sending the email to the client using the smtplib and email.message
    """

    # print("Started the Email Generation!")
    name = str(email_name)
    to = str(emaildata)
    # print(type(to))
    msg = EmailMessage() #calling the function
    verfication_code_random_number = random.randint(1000, 999999) #to print a random number between 1000 and 9999
    #msg.set_content(f"{random_number}") #body text
    mail_content = '''
                Dear Customer,
                I hope this message finds you well. We are thrilled to welcome you to Knowledgeflex and appreciate the opportunity to serve you. As we kick off this partnership, we wanted to provide you with the necessary information to access our dashboard.
                    
                Your Login Credentials:
                Login ID: [Registered email ID]
                Password: admin@123
                [Attach link of VGT for login]

                Please use the above credentials to log in to our dashboard. We recommend changing your password after the initial login for security reasons. If you encounter any issues or have questions, feel free to reach out to us at 9205211982.
                We are committed to ensuring your experience with Knowledgeflex is seamless and productive. Thank you for choosing us, and we look forward to a successful collaboration.
                    
                Best Regards,
                Knowledgeflex Team [Contact Information]'''
    # Replace "Customer" with the extracted first name
    modified_mail_content = mail_content.replace("Customer", name)
    msg.set_content(f"{modified_mail_content}") #body text
  

    msg['subject'] = "Welcome to Knowledgeflex - Your Login Credentials Inside!" #subject of the email
    msg['to'] = to #to address 
 
    # print("Defined the subject and to address!")
    mydoc = mycol.objects.all()# getting all the records from the db
    # print(mydoc)
    for x in mydoc:
        stored_email.append(x.Email)
        
    # print(stored_email)
    # print(to)
    try:
        if to in stored_email:
            # print("Success")
            server = smtplib.SMTP("smtp.gmail.com",587)
            # server = smtplib.SMTP("smtp.office365.com",587)
            server.starttls()
            # print("login!") 
            server.login("kftaiblr@gmail.com", "falmmxkqyxmnttbo")
            server.send_message(msg)
            # print("Email Sent!!")
            server.quit()
            # print("Password is correct.")
            success = {
                    "statusCode":  200,
                    "message": "Sucessful Login",
                    "Verification_Code" : verfication_code_random_number              
                }

            return success

        else:                                           # In case user provided wrong email id which is not registered.

            email_not_found = {

                    "statusCode":  500,
                    "message": "Login Denied, E-mail Not-FOUND",
                    "username": "Unknown"

                }

            return email_not_found
    except Exception as e:
        print("The error:",e)


