'''---25.01.2024, displaying all user name, userid and latest incident occured ---'''
from datetime import datetime
from vgtapp.models import Storing_Answers_To_Checklist

mycol = Storing_Answers_To_Checklist

mycol.objects.filter()
#site = []
#get_N = []
siteN = []
IDs = []
UID = []
main_list = []
show_site = ''

def init_data():
    main_list.clear()
   

def get_incident_report4user1(User_ID):
    print("The line 21!")
    site = []
    get_N = []
    #incident = []
    #dt = []
    get_N = []
    get_admin = []
    
   
    for x in mycol.objects.filter(UserID = str(User_ID)):
        temp = []
        temp1 = []
        temp.append(x.Site_Name)
        uni = set(temp)
        site_val = list(uni)
        site.append(site_val)
    print("Site:",site)
    print("temp:",temp)
    siteN = [item for sublist in site for item in sublist]
    print("Site:",siteN)
    
    for st in siteN:
        for x in mycol.objects.filter(Site_Name = str(st)):
            temp_id = []
            id_val = []
            show_site = str(st)
            temp_id.append(x.UserID)
            uni_id = set(temp_id)
            id_val = list(uni_id)
            IDs.append(id_val)
        print("User ID Present:", IDs)
        tIDN = [item for sublist in IDs for item in sublist]
        tempId = set(tIDN)
        UID = list(tempId)
        print("Show Unique ID:",UID)
        
        for get_ui in UID:            
            for x in mycol.objects.filter(UserID = str(get_ui)):
                get_N.append(x.User_name)
        print("UserName:",get_N)
        tgetN = set(get_N)
        get_N = list(tgetN)
        print("Unique UserName:",get_N)
        
        for i,n in zip(UID, get_N):
            record = {} 
            incident = []
            dt = []           
            for x in mycol.objects.filter(UserID = str(i), User_name = str(n)):
                linci = x.Incident
                incident.append(linci)
                print(incident)
                ldt = x.Registered_Camera_Answer_Response
                dt.append(ldt)
                print(dt)
                
            record = {
                        "Site_Name": show_site,
                        "USER_ID": str(i),
                        "USER_NAME": str(n),
                        "Latest_Incident": incident,
                        "Latest_Incident_Date": dt
                    }
            print("record",record)
            main_list.append(record)
    return main_list

def get_incident_report4user(User_ID, site_name):
    site = []
    get_N = []
    get_incident = []
    get_user = []
    get_userId = []
    dt = []
    get_N = []
    get_admin = 0
    
    for x in mycol.objects.filter(UserID = str(User_ID), Site_Name = site_name):
        temp = x.Admin_id
        get_admin = temp
    
    print("admin_id:",type(get_admin), get_admin)
    
    for x in mycol.objects.filter(Admin_id = get_admin,Site_Name = site_name):
        u_i = x.UserID
        get_userId.append(u_i)
        u_n = x.User_name
        get_user.append(u_n)
    print("user Name:", get_user)
    print("user ID:", get_userId)
    
    for i,n in zip(get_userId, get_user):
            record = {} 
            incident = []
            dt = []           
            for x in mycol.objects.filter(UserID = str(i), Admin_id = get_admin, Site_Name = str(site_name)):
                linci = x.Incident
                incident.append(linci)
                # print(incident)
                ldt = x.Registered_Camera_Answer_Response
                dt.append(ldt)
                print("dt",dt)
            record = {
                        "Site_Name": site_name,
                        "USER_ID": str(i),
                        "USER_NAME": str(n),
                        "Reported_Incident": incident,
                        "Reported_Incident_Date": dt
                    }
            # print(record)
            main_list.append(record)
    print("Show Final Record:", main_list)
    return main_list
        
    

#get_incident_report4user(5,"CISCO_Marathalli")      
    
                
