'''----
program takes the Admin_Id and Registered_Camera_Answer_Response, from there calculate the month 
and store in another collection named monthly_weekly_incident
02.02.2024
-----'''

import pymongo
from datetime import datetime
from vgtapp.models import *

refercol = Storing_Answers_To_Checklist
mycol = monthly_weekly_incident

admin_id_list = []
Incident_list = []
priority_list = []
date_incident_list = []

'''----initializing the DB--------'''
def init_data():
    mydoc = refercol.objects.all()
    admin_id_list.clear()
    Incident_list.clear()
    priority_list.clear()  
    date_incident_list.clear()
    for x in mydoc:
        
        admin_id_list.append(x.Admin_id)
        Incident_list.append(x.Incident)
        priority_list.append(x.Priority)
        date_incident_list.append(x.Registered_Camera_Answer_Response)


'''---getting the related information for month,year and week ----'''
def get_date_info(date):
    date_str = str(date)  # Assuming the format is DD/MM/YYYY

    # Convert string to datetime object
    date = datetime.strptime(date_str, "%d/%m/%Y")

    # Extract month abbreviation (e.g., Jan)
    month = date.strftime("%b")

    # Extract year
    year = date.strftime("%Y")

    # Calculate which week of the month
    week = (date.day - 1) // 7 + 1
    week = "first" if week == 1 else "second" if week == 2 else "third" if week == 3 else "fourth" if week == 4 else "fifth"

    # print("Month:", month)
    # print("Year:", year)
    # print("Week:", week + " week")

    return month,year,week



def information():
    try:
        '''--- get the required data from the collection named: Storing_Answers_To_Checklist---'''
        adminId = ''
        incident_happen = ''
        incident_priority = ''
        date = ''
        mydoc = refercol.objects.all()
        for x in mydoc:
            # print("The docs are:",x)
            #admin_id_list.append(x['Admin_UserID'])
            adminId = x.Admin_id
            #Incident_list.append(x['Incident'])
            incident_happen = x.Incident
            #priority_list.append(x['Priority'])
            incident_priority = x.Priority
            #date_incident_list.append(x['Registered_Camera_Answer_Response'])
            date = x.Registered_Camera_Answer_Response
            
            m,y,w = get_date_info(date)

            info = {
                "Admin_UserID": adminId,
                "Incident_Happened": incident_happen,
                "Incident_Priority": incident_priority,
                "Incident_Month": m,
                "Incident_Week": w,
                "Incident_Year": y
            }

            info = mycol.objects.create(
                Admin_UserID = info["Admin_UserID"],
                Incident_Happened = info["Incident_Happened"],
                Incident_Priority = info["Incident_Priority"],
                Incident_Month = info["Incident_Month"],
                Incident_Week = info["Incident_Week"],
                Incident_Year = info["Incident_Year"]
            )
            
            info.save()
    except Exception as e:
        print("error",e)
