from django.urls import path 
from vgtapp import views
from django.urls import re_path
# from Guardapp.views import live_stream_rtsp
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls.static import static
from django.conf import settings
from django.conf import settings
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns=[
    path("Dashboard/", views.Dashboard, name="Dashboard"),
    path("Registration/", views.Registration, name="Registration"),
    path("Base/", views.Base, name="Base"),
    path('', views.signin, name="signPage"),
    path("UserDashboard/", views.UserDashboard, name="UserDashboard"),
    path("Checklist/", views.Checklist, name="Checklist"),
    path("Cameraonboard/", views.Cameraonboard, name="Cameraonboard"),
    path("test/", views.test, name="test"),
    path("Sites/", views.Sites, name="Sites"),
    path("Createsite/", views.Createsite, name="Createsite"),
    path("Patroltask/", views.Patroltask, name="Patroltask"),
    path("Routes/", views.Routes, name="Routes"),
    path("Role/", views.Role, name="Role"),
    path("SiteManagement/", views.SiteManagement, name="SiteManagement"),
    path("Route/", views.Routes, name="Route"),
    path("RouteManagement/", views.RouteManagement, name="RouteManagement"),
    path("Login/", views.Login, name='Login'),
    path("Forgotpassword/", views.Forgotpassword, name='Forgotpassword'),
    path("VGTRouteRegistration_Post/", views.VGT_Route_Registration_Post, name='VGTRouteRegistration'),
    path('Checklistedit/',views.Checklistedit, name='Checklistedit'),

    
    path('User_SignIn/', views.User_SignIn, name="login"),
    path('admin_register/', views.clientadmin_reg, name='admin_register'), #DELETE
    path('get_all_admin_register/',views.get_all_admin_users, name='get_alladmin_register'),
    path('delete-clientinfo/',views.Delete_clientinfo, name = 'delete-clientinfo'), #DELETE 
    path('updatepassword/',views.User_updatepassword,name='update_pass'), #password_update
    path('Camera_register/',views.Add_device,name='add_device'), #onboarding Camera
    path('Verification/',views.User_Otpverification,name='User_Otpverification'), #otp_verification
    # path('Signout/',views.Signout_details,name='logout'), 

    path('specific-delete-Siteip-id/', views.Delete_Siteinfo, name='specific-delete-Siteip-ip'), #DELETE
    path('specific-delete-username-mailid/', views.Delete_username_mail, name='specific-delete-username-mailid'), #DELETE
    
    #Give the live-stream
    path('live_stream/<str:Site_Name>/<int:CameraIndex>/', views.live_stream_rtsp, name='live_stream'),
    
    #Define the video url
    # path('getvideo_url/', views.getvideo_url, name='video_url'),
    # path('get_video_Path/', views.get_video_Path, name='get_video_Path'),
    path('camera_counts/', views.Get_totalcamera_counts, name='No_of_cameras'),   
    path('getallRegisteredCameras/', views.get_all_Registered_Cameras, name='get_all_Registered_Cameras'),    
    path('get_site_management_information/', views.get_site_management_information, name='get_site_management_information'),
    path('UserManagement/',views.UserManagement,name='UserManagement'),
    path('Manage_Checklist/',views.Manage_Checklist,name='Manage_Checklist'),
    path('get_vgt_checklist/', views.get_VGT_Check_list_Info, name='get_vgt_checklist'),

    #Define the User_Information
    path('add_users_info/',views.vgt_add_user_info, name='add_users_info'),
    path('delete_uname_mobile/',views.Delete_username_mobile, name='delete_uname_mobile'), #DELETE
    path('User_manag_info/', views.get_user_management_info, name='get_user_management_info'),
    path('Route_Management/',views.Route_Management,name='Route_Management'),
    path('vgt_updaterouteinfo/', views.vgt_updateroute_info, name='vgt_updaterouteinfo'),
    path('del_route_site/',views.delete_route_site_name,name='del_route_site'), #DELETE
    path('VGT_Route_Registration/',views.VGT_Route_Registration_Post, name='VGT_Route_Registration'),    
    path('Mapped_Route_Registration/',views.Mapped_Route_Registration, name='Mapped_Route_Registration'),
    path('Delete_mappedroute_info/',views.Delete_mappedroute_info, name='Delete_mappedroute_info'), #DELETE
    path('user_info_dashboard/<str:User_Name>/', views.user_info_dashboard, name='user_info_dashboard'),
    path('add_site/', views.vgt_add_site,name='vgt_add_site'),
    path('site_name_code/', views.get_site_name_code,name='site_name_code'),
    path('del_site_code_info/',views.Delete_site_code_name, name='del_site_code_info'), #DELETE    
    path('sitename/',views.sitename, name='sitename'),

    #Define events path and answer checklist
    path('get_ans_checklist/',views.get_vgt_ans_checklist, name= 'get_ans_checklist'),
    path('ans_checklist/', views.vgt_ans_checklist, name = 'ans_checklist'),
    # path('events_path/', views.get_eventsimgpath, name='events_path'),

    #Define imagepath and Mp4 path
    # path('get_vgt_imagepath/',views.get_vgt_imagepath, name='vgt_imagepath'),
    path('post_vgt_imagepath/',views.post_vgt_captureimage, name='post_vgt_imagepath'),
    # path('getvgt_Mp4path/',views.get_vgt_Mp4path, name='getvgt_Mp4path'),
    path('postvgt_captureMp4/',views.post_vgt_captureMp4, name='postvgt_captureMp4'),

    #Define weekly/monthly/daily/patrolling reports
    path('vgt_patrollingreport/<str:adminid>/',views.vgt_patrolling_report, name = 'vgt_patrollingreport'),
    path('vgt_weekreport/<str:admin>/',views.vgt_weekly_report, name = 'vgt_weekreport'),
    path('vgt_dailyreport/<str:admin>/',views.vgt_daily_report, name = 'vgt_dailyreport'),
    path('vgt_monthlyreport/<str:Admin_UserID>/',views.get_vgt_monthly_report, name = "vgt_monthlyreport"),


    #Define site routes
    path('siten_adminid_route_nonp/',views.siten_adminid_routen, name = 'siten_adminid_route_nonp'),
    # path('siten_adminid_route_para/',views.siten_adminid_routen_para, name= 'siten_adminid_routen_para'),
    path('update_idnamephone/',views.update_idnamephone, name = 'update_idnamephone'),
    
    #update siteroute & cameraquestion
    # path('vgtupdate_siteroutecamera/',views.vgt_update_siteroutecamera, name = 'vgtupdate_siteroutecamera'),
    # path('vgtupdate_cameraquestion/',views.vgt_update_cameraquestion, name = 'vgtupdate_cameraquestion'),
    # path('vgt_deletequestion/',views.vgt_delete_question, name = 'vgt_deletequestion'),

    path("Incident/", views.Incident, name='Incident'),    
    path('vgt_alternate_feed/<int:Admin_ID>/', views.vgt_alternate_live_feed, name='vgt_alternate_feed'),
    path('vgt_incidentreport_adminID/<int:ADMIN_ID>/',views.vgt_incident_report_adminID, name='vgt_incidentreport_adminID'),
    path('vgt_incidentreport_adminID/',views.vgt_incident_report_adminID, name='vgt_incidentreport_adminID'),  
    path('vgt_patrollingreport_adminID/<int:ADMIN_ID>', views.vgt_patrolling_report_adminID, name='vgt_patrollingreport_adminID'),
    path('vgt_incidentid_dashboard/<int:USER_ID>/<str:SITE_NAME>/',views.vgt_user_incidentid_report_dashboard, name='vgt_incidentid_dashboard'),

    #Define checkuser and assigning incidents
    # path('_vgt_checkuser/',views.vgt_checkuser, name='_vgt_checkuser'),
    # path('vgt_assign_incident/', views.assign_incident, name = 'vgt_assign_incident'),
    #Define livefeed path
    # path('vgt_info_livefeed/',views.vgt_get_info_livefeed, name = 'vgt_info_livefeed'),

    #Pages for ai
    path('AiRoutes/',views.AiRoutes,name="AiRoutes"),
    path('AiCameraCenter/',views.AiCameraCenter,name="AiCameraCenter"),

    #AI_get and post
    # path('AI_check_register/', views.AI_checklist_register, name='AI_check_register'),
    # path('get_airoute_manage/',views.get_ai_route_management_info, name = 'get_airoute_manage'),
    # path('AI_register_user/',views.AI_user_register, name='AI_register_user'),
    # path('get_checklist_info/',views.get_ai_checkList_info, name='get_checklist_info'),
    # path('Person_Detection_Module/',views.Person_Detection_Module, name='Person_Detection_Module'),

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
    
urlpatterns += staticfiles_urlpatterns()
