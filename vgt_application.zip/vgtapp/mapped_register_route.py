import pymongo
from datetime import datetime

from vgtapp.models import Mapped_Route_Management

# data = Mapped_Route_Management.objects.all()

c_n=[]

def mapped_route_info(data):
    # f_n = data.First_Name
    # l_n = data.Last_Name
    
    admin_id = data["Admin_userid"]
    user_name = data["USER_NAME"]
    r_n = data["Route_Name"]
    s_n = data["Site_Name"]
    s_c = data["Site_Code"]
    # Schedule_Time = data.Schedule_Time
    start_date_time =  data["Start_Date_Time"]
    End_Date_Time = data["End_Date_Time"]
    c_n = data["Camera_Name"]
    print("The camera:",c_n,type(c_n))
    if start_date_time != "string" :
        print("Correct time!")
        info = {
        "USER_NAME": user_name,
        "Site_Name": s_n,
        "Site_Code": s_c,
        "Route_Name": r_n,
        "Admin_UserID" : admin_id,
        # "Schedule_Time":Schedule_Time,
        "Start_Date_Time": start_date_time,
        "End_Date_Time": End_Date_Time,
        "Camera_Name": c_n,
        "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p"),
        "DateOfCameraRegistration_Dateformat" : (datetime.today()).strftime("%d/%m/%Y")
            }
        vgt_route = Mapped_Route_Management.objects.create(    
            USER_NAME= info["USER_NAME"] ,
            Site_Name= info["Site_Name"],
            Site_Code= info["Site_Code"],
            Route_Name= info["Route_Name"] ,
            Admin_UserID= info["Admin_UserID"],
            Start_Date_Time= info["Start_Date_Time"] ,
            End_Date_Time= info["End_Date_Time"]  ,
            Camera_Name= info["Camera_Name"]  ,
            DateOfCameraRegistration= info["DateOfCameraRegistration"] ,
            DateOfCameraRegistration_Dateformat = info["DateOfCameraRegistration_Dateformat"] 
        )
        vgt_route.save()
        show = {
                        "Status":200,
                        "message": "USER AND ROUTE MAPPED SUCCESSFULLY!!",
                        "username": user_name,
                                    
                }
    else:
        print("Incorrect time!")
        show = {
                "Status":500,
                "message": "INCORRECT TIME",
                "username": user_name,
                            
        }
    
    return show
