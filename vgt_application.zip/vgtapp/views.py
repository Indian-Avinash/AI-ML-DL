from django.shortcuts import render
from django.shortcuts import render
from datetime import datetime,timedelta
from django.views.decorators.csrf import csrf_exempt
import requests, json
from urllib.parse import urlparse
import vgtapp.login as lg
from django.http import HttpResponse,JsonResponse, StreamingHttpResponse
import cv2, queue
from vgtapp.models import *
from datetime import datetime
import time
# from vgtapp.models import get_VGT_CameraInfo
# from vgtapp.models import get_VGT_CameraInfo

# Create your views here.
def Dashboard(request):
    return render (request, 'Dashboard.html')
def Registration(request):
    return render (request, 'Registration.html')
def Base(request):
    return render (request, 'Base.html')
def signin(request):
    return render (request, 'Login.html')
def UserDashboard(request):
    return render (request, 'UserDashboard.html')
def Checklist(request):
    return render (request, 'Checklist.html')
def Cameraonboard(request):
    return render (request, 'Cameraonboard.html')
def test(request):
    return render (request, 'test.html')
def Sites(request):
    return render (request, 'Sites.html')
def Createsite(request):
    return render (request, 'Createsite.html')
def Routes(request):
    return render (request, 'Routes.html')
def Patroltask(request):
    return render (request, 'Patroltask.html')
def Role(request):
    return render(request, 'Role.html')
def SiteManagement(request):
     return render(request, 'SiteManagement.html')
def RouteManagement(request):
    return render(request, 'RouteManagement.html')
def Login(request):
    return render(request, 'Login.html')
def Forgotpassword(request):
    return render(request, 'Forgotpassword.html')
def UserManagement(request):
    return render(request, 'UserManagement.html')
def Incident(request):
    return render (request, 'Incident.html')
def Checklistedit(request):
    return render(request, 'Checklistedit.html')

def AiRoutes(request):
    return render(request,'AiRoutes.html')
def AiCameraCenter(request):
    return render(request,'AiCameraCenter.html')


#@***************User_login***************@
@csrf_exempt
def User_SignIn(request):
      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        print("the json data:",json_data)
        loginEmail_Mobile = json_data["EmailId"],
        loginpassword = json_data["Password"],

        access = lg.Login(loginEmail_Mobile,loginpassword)
        
        print("output of r:", access)    

    return JsonResponse(access)
 
#@***************User_clientadmin_Registration***************@
@csrf_exempt
def clientadmin_reg(request):
    # print("Request received")
    print("Line 127")
    data = {}
    if request.method == "POST":
        print("\n\n POST REQUEST RECEIVED! 😉\n\n")
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        import vgtapp.admin_registration as ar
        ar.init_data()

        user = {
            "FirstName"  : json_data["FirstName"],
            "LastName"  : json_data["LastName"],
            "Company_Name"  : json_data["Company_Name"],
            "Department"  : json_data["Department"],
            "Designation" : json_data["Designation"],
            "Phone" : json_data["Phone"],
            "Email"  : json_data["Email"],
            "Location"  : json_data["Location"]
        }
        access = ar.registration(user)
        # print("The access value is:",access)
        # user.save()
        statusCode = access["statusCode"]
 
    return JsonResponse({'statusCode':statusCode,'success': False})

#@***************Get Admin registered***************@
@csrf_exempt
def get_all_admin_users(request):      
    mydb = admin
    
    admin_list = []
    for dict in mydb.objects.all():
        admin_list.append(dict.Admin_Unique_UserID)

    return JsonResponse(admin_list, safe=False)

#@***************User_Client_deleteinfo***************@
@csrf_exempt
def Delete_clientinfo(request,User_Name,Emailid):
    
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("hello there")
        data = {
            "User_Name": json_data["User_Name"],   
            "Emailid": json_data["Emailid"],
        }
        mycol = admin
        
        saved_admin_database = []
        
        for dict in mycol.objects.filter(USER_NAME=data["User_Name"],EMAIL = data["Emailid"]):
            saved_admin_database.append(dict)
            mycol.objects.filter(USER_NAME=User_Name,EMAIL = Emailid).delete()
        
        if len(saved_admin_database) !=0:
            response = {"Status":200,
                        "Deleted Dictionary are":saved_admin_database}
        else:
            response = {"Status":500,
                        "Message":"Data not found"}

        # try:
        paste_url = response["Status"]                      
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(response["Status"])
    return JsonResponse({'status':paste_url,'success': False})


#@***************Password_update***************@
@csrf_exempt
def User_updatepassword(request):
    # print('Request Recieved')
    # URL = 'http://127.0.0.1:65/VGT/password_update/'
    if request.method == 'PUT':
        print('post request recieved')
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "loginEmail_Mobile": json_data['loginEmail_Mobile'],
            "Newpassword": json_data['Newpassword'] 
        }
        print('Login:', data["loginEmail_Mobile"])
        print('Password:', data["Newpassword"])
        # r = requests.put(url=URL, json=data)

        mycol = admin
        print(data["loginEmail_Mobile"].isnumeric())
        #Updating the password by the given email id
        if data["loginEmail_Mobile"].isnumeric()==True:
            mycol.objects.filter(Phone = data["loginEmail_Mobile"]).update(PASSWORD = data["Newpassword"])
        else:
            mycol.objects.filter(Email = data["loginEmail_Mobile"]).update(PASSWORD = data["Newpassword"])
       
        # return{"Message":f"Password for {data["loginEmail_Mobile"]} has been updated."}
        # print("output of r", r)
        # try:
        #     paste_url = "200"
        #     # print(r.status_code)
        #     print('The paste_url is: %s' % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print("Line 726:",paste_url)
    return JsonResponse({'success': False})
 
#@***************Camera_Registration***************@
@csrf_exempt
def Add_device(request):
    data = {}
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        # create the dictionary to send in the post request
        data = {
            "Admin_id": json_data["Admin_id"],
            "Site_Name": json_data["Site_Name"],
            "Site_Code": json_data["Site_Code"],
            "CameraName": json_data["CameraName"],
            "CameraType": json_data["CameraType"],
            "CameraRTSP": json_data["CameraRTSP"],            
            "Region": json_data["Region"],
            "City": json_data["City"],
            "Location": json_data["Location"],
            "TimeZone": json_data["TimeZone"],
        }
    
    import vgtapp.Register_camera as rc
    rc.init_data(admin=data["Admin_id"])
    access = rc.VGT_camera_register_info(data)

    # try:
    #     status_code = "200"
    #     paste_url = access
    #     print(status_code)
    #     print(type(paste_url))
    #     print("The paste_url is: %s" %paste_url)            
    #     return HttpResponse(access)
    # except Exception as e:
    #     print(status_code)
    return JsonResponse(access)
 
 
#@***************Generating_Verification_Code***************@
@csrf_exempt
def User_Otpverification(request):
    # print('Request Recieved')
    # URL = 'http://127.0.0.1:65/VGT/Generating_Verification_Code/'
    if request.method == 'POST':
        print("post request recieved for verification!")
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "Email": json_data["Email"]
        }
        print('Email:', data["Email"])
        
        import vgtapp.mail_verification as m      
        code = m.email_alert(data["Email"])

        print("The code:",code)
        # r = requests.post(url=URL, json=data)
        # print("output of r:", r)
        # try:
        #     paste_url = code
        #     # print(r.status_code)
        #     # print("The paste_url is: %s" % paste_url)
        #     # return JsonResponse({'success': True, "username": paste_url["username"]})
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(paste_url)
    return JsonResponse({'Verification Code':code,'success': False})
 
#@***************logout***************@
# @csrf_exempt
# def Signout_details(request):
#     # print("Request received")
#     data = {}
#     URL = 'http://127.0.0.1:65/VGT_User_LogOut/'      
#     if request.method == "PUT":
#         # to receive image data as JSON payload in the body of the request
#         # we need to use request body
#         json_data = json.loads(request.body.decode('utf-8'))
#         data = {
#             "Email": json_data["Email"],
#             "USER_NAME": json_data["UserName"],
#         }       
#         r = requests.put(url=URL, json=data)
#         # print("output of r:", r)
#     # return JsonResponse({"Message": "data recerived"})
#         # try:
#         #     paste_url = r.text
#         #     # print(r.status_code)
#         #     print("The paste_url is: %s" % paste_url)
#         #     return HttpResponse(paste_url)
#         # except Exception as e:
#         #     print(r.status_code)
#     return JsonResponse({'success': False})

#@***************Specificinfo_delete_sites***************@
@csrf_exempt
def Delete_Siteinfo(request,SiteName,SiteID,CameraIP):
    
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("hello there")
        data = {
            "SiteName": json_data["SiteName"],   
            "SiteID": json_data["SiteID"],
            "Camera_IP": json_data["Camera_IP"]
        }
        URL = f"http://127.0.0.1:65/Delete_With_SiteName_SiteID_IP/{SiteName},{SiteID},{CameraIP}"
        resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
        print("output of r:", resp)
        # try:
        #     paste_url = resp.text                      
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(resp.Status)
    return JsonResponse({'success': False})

#@***************Specificinfo_delete_username_mailid***************@
@csrf_exempt
def Delete_username_mail(request,USER_NAME,Mail_ID):
    
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("hello there")
        data = {
            "USER_NAME": json_data["USER_NAME"],   
            "Mail_ID": json_data["Mail_ID"],            
        }
        URL = f"http://127.0.0.1:65/Delete_With_UserName_Email/{USER_NAME},{Mail_ID}"
        resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
        print("output of r:", resp)
        # try:
        #     paste_url = resp.text                      
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(resp.Status)
    return JsonResponse({'success': False})
 
#@***************Get No_of_counts_Camera_details per ProfileName***************@
def Get_totalcamera_counts(request):  
    from vgtapp.models import site_management
    import vgtapp.site_management as sm
    import vgtapp.get_update_site as gp    
    gp.site_management_camera_update()
    sm.site_management_info() 
    list_sites = []   
    site_data = site_management.objects.all()
    for docs in site_data:
        docs.Admin_id
        list_sites.append(
        {
            "Site_Name" : docs.Site_Name,
            "Site_Code" : docs.Site_Code,
            "Region" : docs.Region,
            "Branch" : docs.Branch,
            "Admin_id" : docs.Admin_id,
            "Zone" : docs.Zone,
            "No_Route" : docs.No_Route,
            "is_action" : docs.is_action,
            "No_Of_Camera" : docs.No_Of_Camera
        })
   
    return JsonResponse(list_sites, safe=False)
 
#@*************** route registration***************@
@csrf_exempt
def VGT_Route_Registration_Post(request):
    # print("Request received")
    data = {}
    # URL = 'http://127.0.0.1:65/VGT/VGT_Route_Registration/'      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "Route_Name": json_data["Route_Name"],
            "Site_Name": json_data["Site_Name"],
            "Admin_userid": json_data["Admin_userid"],
        }
        # print('Email:', data["Email"])
        # print('Delete_username:', data["USER_NAME"])
        # r = requests.post(url=URL, json=data)
        import vgtapp.register_route as rr   
        req = rr.route_info(data)

    return JsonResponse({'success': False})

#@*************** mapped route registration***************@
@csrf_exempt
def Mapped_Route_Registration(request):
    # print("Request received")
    data = {}      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        print("the json data:",json_data)
        data = {
            "USER_NAME": json_data["USER_NAME"],            
            "Route_Name": json_data["Route_Name"],
            "Site_Name": json_data["Site_Name"],
            "Site_Code": json_data["Site_Code"],
            # "Schedule_Time": json_data["Schedule_Time"],
            "Start_Date_Time": json_data["Start_Date_Time"],
            "End_Date_Time": json_data["End_Date_Time"],
            "Camera_Name": json_data["Camera_Name"],
            "Admin_userid": json_data["Admin_userid"]
        }
        import vgtapp.mapped_register_route as rr   
        req = rr.mapped_route_info(data)
        # return req
        # print('Email:', data["Email"])
        # print('Delete_username:', data["USER_NAME"])
        # r = requests.post(url=URL, json=data)
        # print("output of r:", r)
    # return JsonResponse({"Message": "data recerived"})
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
    return JsonResponse({'success': False})
#@***************Specific_delete_mappedroute_info***************@
@csrf_exempt
def Delete_mappedroute_info(request,site_name,Schedule_Time,site_code,Route_Name):
    
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("The json data:",json_data)
        print("hello there")
        data = {
            "site_name": json_data["site_name"],   
            "Schedule_Time": json_data["Schedule_Time"],   
            "site_code": json_data["site_code"],
            "Route_Name": json_data["Route_Name"]         
        }
        # URL = f"http://127.0.0.1:65/VGT/Delete_Mapped_Route_Management/{site_name},{Schedule_Time},{site_code},{Route_Name}"
        # resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
           

        mydb = Mapped_Route_Management
        delete_mapped_route_list = []
        mydb.objects.filter(Site_Name=site_name,Schedule_Time=Schedule_Time,Site_Code=site_code,Route_Name=Route_Name).delete()
        for dict in mydb.objects.filter(Site_Name=site_name,Schedule_Time=Schedule_Time,Site_Code=site_code,Route_Name=Route_Name):
            delete_mapped_route_list.append(dict)
        
        if len(delete_mapped_route_list) != 0:
            res = {"Status": 200,
                "Deleted_doc":delete_mapped_route_list}
        else:
            res = {"Status":500,
                "Message":"Data Not Found"}
        
        print("output of r:", res)
        # try:
        #     paste_url = resp.text                      
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(resp.Status)
    return JsonResponse({'success': False})
 
#@***************Get camera registered***************@
def get_all_Registered_Cameras(request):      
    # response = requests.get('http://127.0.0.1:65/VGT/get_all_Registered_Cameras/')  
    from vgtapp.models import Camera_info
    print("API Response has been stored")  
    # data = response.json()  
    # print(type(data))
    # print("Jitesh")   
    cameradata = Camera_info.objects.all()
    list_of_cameras = []
    for data in cameradata:
        list_of_cameras.append({
            "Site_Name" : data.Site_Name , 
            "Site_Code" : data.Site_Code , 
            "CameraName" : data.CameraName ,
            "CameraType" : data.CameraType ,
            "CameraRTSP" : data.CameraRTSP ,
            "CameraIP" : data.CameraIP , 
            "CameraID" : data.CameraID , 
            "Admin_unique_id" : data.Admin_unique_id , 
            "Region" : data.Region , 
            "City" : data.City , 
            "Location" : data.Location , 
            "TimeZone" : data.TimeZone , 
            "is_active" : data.is_active ,
            "is_AutoRecording" : data.is_AutoRecording ,
            "Site_Camera_Count" : data.Site_Camera_Count , 
            "DateOfCameraRegistration" : data.DateOfCameraRegistration 
        })
    print("The list_of_cameras",list_of_cameras)

    return JsonResponse({"data":list_of_cameras, "success":False})
 
#@***************Post_vgt_checklist***************@
@csrf_exempt
def Manage_Checklist(request):
    from vgtapp.models import check_list
    # print("Request received")
    data = {}
    #URL = 'http://127.0.0.1:65/VGT_Creating_check_list/'      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "Admin_UserID": json_data["Admin_UserID"],
            "Site_Name": json_data["Site_Name"],
            "Route_Name": json_data["Route_Name"],
            "Camera_Name": json_data["Camera_Name"],
            "Add_check_query": json_data["Add_check_query"],      
            "Question_Type": json_data["Question_Type"] ,
            "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p"),
            "DateofCameraRegistration_DateFormat": (datetime.today()).strftime("%d/%m/%Y")    
        }        
        checklist_data = check_list.objects.create(          
            Site_Name = data["Site_Name"],
            Route_Name = data["Route_Name"] ,
            Camera_Name = data["Camera_Name"],
            Add_check_query = data["Add_check_query"],
            Admin_UserID = data["Admin_UserID"] ,
            Type = data["Question_Type"] ,
            DateOfCameraRegistration = data["DateOfCameraRegistration"],
            DateofCameraRegistration_DateFormat = data["DateofCameraRegistration_DateFormat"]
        )
        checklist_data.save()
        print("Saved the checklist data!")
        #r = requests.post(url=URL, json=data)        
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
    return JsonResponse({'success': False})

# #@***************Post_vgt_checklist***************@
# @csrf_exempt
# def Manage_Checklist(request):
#     # print("Request received")
#     data = {}
#     req = ''
#     # URL = 'http://127.0.0.1:65/VGT_Creating_check_list/'      
#     if request.method == "POST":
#         # to receive image data as JSON payload in the body of the request
#         # we need to use request body
#         json_data = json.loads(request.body.decode('utf-8'))
#         data = {
#             "Admin_UserID": json_data["Admin_UserID"],
#             "Site_Name": json_data["Site_Name"],
#             "Route_Name": json_data["Route_Name"],
#             "Camera_Name": json_data["Camera_Name"],
#             "Add_check_query": json_data["Add_check_query"],      
#             "Question_Type": json_data["Question_Type"]      
#         }        
#         # r = requests.post(url=URL, json=data)  
        
#         from vgtapp import create_checklist as cc
#         #cc.init_data()
#         req = cc.create_check_list(data)
#         # return req      
#         '''--------'''
#         # try:
#         #     paste_url = r.text
#         #     # print(r.status_code)
#         #     print("The paste_url is: %s" % paste_url)
#         #     return HttpResponse(paste_url)
#         # except Exception as e:
#         #     print(r.status_code)
#     return JsonResponse({'Data':req,'success': False})
 
#@***************Get_vgt_checklist***************@
def get_VGT_Check_list_Info(request):      
    # response = requests.get('http://127.0.0.1:65/VGT_Check_list_Info/')  
    # print("API Response has been stored")  
    # data = response.json()  
    # print(type(data))
    # # print("Jitesh")
    list_of_checklist = []
    check_list_data = check_list.objects.all() 
    for docs in check_list_data: 
        list_of_checklist.append({
            "Site_Name": docs.Site_Name,
            "Route_Name": docs.Route_Name,
            "Camera_Name": docs.Camera_Name,
            "Add_check_query": docs.Add_check_query,
            "Admin_UserID": docs.Admin_UserID,
            "Type": docs.Type,
            "DateOfCameraRegistration": docs.DateOfCameraRegistration ,
            "DateofCameraRegistration_DateFormat": docs.DateofCameraRegistration_DateFormat
        })  
    return JsonResponse({"data":list_of_checklist, "success":False})  
    # return JsonResponse({"success":False})           
 
#@***************GetSitemanagementinfo***************@
def get_site_management_information(request):
    
    # response = requests.get("http://127.0.0.1:65/VGT/get_site_management_information/")
    print("API Response has been stored")  
    
    import vgtapp.site_management as sm
    import vgtapp.get_update_site as gp    
    gp.site_management_camera_update()
    sm.site_management_info()
    list_sites = []    
    # doc = json.loads(site_management.objects.to_json())
    site_data = site_management.objects.all()
    for docs in site_data:
        list_sites.append(
        {
            "Site_Name" : docs.Site_Name,
            "Site_Code" : docs.Site_Code,
            "Region" : docs.Region,
            "Branch" : docs.Branch,
            "Admin_id" : docs.Admin_id,
            "Zone" : docs.Zone,
            "No_Route" : docs.No_Route,
            "is_action" : docs.is_action,
            "No_Of_Camera" : docs.No_Of_Camera
        })
        
    return JsonResponse(list_sites, safe=False)
 
 
#@***************Live streaming***************@
def get_camera_info_from_api(site_name):
    try:
        # api_endpoint = f"http://127.0.0.1:65/VGT_with_site_name_get_cam_info/?site_name={site_name}"       
        # response = requests.get(api_endpoint)
        
        # myclient = pymongo.MongoClient("mongodb://localhost:27017/")
        # mydb = myclient["Guard_Patrol"]
        mycol = Camera_info

        temp_camera_name = []
        temp_camera_rtsp = []
        loc = []
        for x in mycol.objects.filter(Site_Name = site_name):
            # print(x)
            temp_camera_name.append(x.CameraName)
            temp_camera_rtsp.append(x.CameraRTSP)
            loc.append(x.Location)
        data = {
            "Site_Name": site_name,
            "CameraName": temp_camera_name,
            "CameraRTSP": temp_camera_rtsp,
            "Location": set(loc)
        }
        # print(data)
        
        # return data
        # print("response:", response)
        # if response.status_code == 200:
        #     return response.json()
        # else:
        #     return None
    except requests.RequestException as e:
        print(f"API Error: {e}")
        return None   
    
    return JsonResponse(data)   

def live_stream_rtsp(request, Site_Name=None, CameraIndex=None):
    if not Site_Name:
        return HttpResponse("Site_Name is required.")
 
    api_data = get_camera_info_from_api(Site_Name)
    print("api_data",api_data)
    if not api_data:
        return HttpResponse("Error fetching camera info from API.")
 
    try:
        site_name = api_data["Site_Name"]
        camera_names = api_data["CameraName"]
        camera_rtsp_urls = api_data["CameraRTSP"]
    except KeyError:
        return HttpResponse("Incomplete data received from API.")
 
    if site_name == Site_Name:
        if CameraIndex is not None and 0 <= CameraIndex < len(camera_names):
            rtsp_url = camera_rtsp_urls[CameraIndex]
            rtsp_url = "C:/venv_127_0_0_1/venv/VGT_API/06_05_2024_18_29_50.mp4"
            print("rtsp_url:", rtsp_url)
    
            # cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
            # if not cap.isOpened():
            #     return HttpResponse("Failed to open camera stream.")
 
            def generate_frames():
                try:
                    cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
                    count = 0
                    while cap.isOpened():
                        ret, frame = cap.read()
                        if not ret:
                            print("Failed to read frame from the camera stream.")
                            cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
                            continue
                        count += 1 
                        if count %2 != 0 or count %3 != 0: 
                            continue 
                        frame = cv2.resize(frame, (800, 600))
                        _, jpeg = cv2.imencode('.jpg', frame)
                        yield (b'--frame\r\n'
                               b'Content-Type: image/jpeg\r\n\r\n' + jpeg.tobytes() + b'\r\n\r\n')
                except GeneratorExit:
                    cap.release()
                    print("Video capture object released.")
 
            return StreamingHttpResponse(generate_frames(), content_type='multipart/x-mixed-replace; boundary=frame')
        else:
            return HttpResponse("Invalid camera index.")
    else:
        return HttpResponse("Site_name mismatch.")
def reopen_capture(url):
    max_retries = 3  # Maximum number of retries to reopen the capture
    retries = 0
    cap = None  # Initialize the video capture object
    while retries < max_retries:
        if cap is not None:
            cap.release()  # Release the previous video capture object if any
 
        cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)  # Reopen the video capture object
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))  # Set the codec to MJPEG
        cap.set(cv2.CAP_PROP_FPS,15)  # Set the frame rate (adjust as needed)
 
        if cap.isOpened():
            print("Video capture reopened successfully.")
            return cap
        else:
            retries += 1
            print(f"Failed to reopen video capture. Retrying... ({retries}/{max_retries})")
            time.sleep(2)  # Wait for a few seconds before retrying
 
    print("Failed to reopen video capture after multiple retries.")
    return None    

# @***************Sitename***************@
@csrf_exempt
def sitename(request):
    # print("Request received")
    data = {}     
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        print("The json data:",json_data)
        data = {            
            "Site_Name": json_data["Site_Name"]
        }        
        # r = requests.post(url=URL, json=data) 

    mycol = Camera_info
    sitename = data["Site_Name"]
    reqData = []
    # url_host = "http://122.166.48.42:9092/live_stream/"
    url_host = "http://127.0.0.1:8000/live_stream/"
    # url_host = config.url_host
    # url_host = "http://122.166.48.42:9096/live_stream/"
    changed_sitename = sitename.replace(' ', '%20')
    doc = mycol.objects.filter(Site_Name = sitename)
    for x in doc:
        
        docs = {
            "Site_Name": x.Site_Name,
            "Site_Code": x.Site_Code,
            "CameraName": x.CameraName,
            "CameraType": x.CameraType,
            "CameraRTSP": x.CameraRTSP,
            "CameraIP": x.CameraIP,
            "CameraID": x.CameraID,
            "Admin_unique_id": x.Admin_unique_id,
            "Region": x.Region,
            "City": x.City,
            "Location": x.Location,
            "TimeZone": x.TimeZone,
            "is_active": x.is_active,
            "is_AutoRecording": x.is_AutoRecording
            # "Site_Camera_Count": x.sit
            # "DateOfCameraRegistration": x.Dateof
            }
        reqData.append(docs)
    
    index = 0
    for req in reqData:
        urlPath = url_host + changed_sitename + f"/{index}"
        req["StreamingURL"] = urlPath
        # print(req,"\n\n\n\n")
        index += 1
           
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
    return JsonResponse({'Data':reqData,'success': False})
 
#@***************Post_vgt_Add_user_Page_info***************@
@csrf_exempt
def vgt_add_user_info(request):
    # print("Request received") 
    data = {}
    # URL = 'http://127.0.0.1:65/VGT_Add_User_Page_info/'      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "First_Name": json_data["First_Name"],
            "Last_Name": json_data["Last_Name"],
            "Site_Name": json_data["Site_Name"],
            "Site_Code": json_data["Site_Code"], 
            "Designation": json_data["Designation"],
            "Admin_UserID": json_data["Admin_UserID"],
            "Mobile": json_data["Mobile"], 
            "Email": json_data["Email"]            
        }        
        # r = requests.post(url=URL, json=data)     
        
        import vgtapp.add_user_page as ap
        #cc.init_data()
        req = ap.add_user_page(data)
        # return req   
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
    return JsonResponse({'success': False})
 

 #@***************Specific_delete_username_email_mobile***************@
@csrf_exempt
def Delete_username_mobile(request):  # removing the email parameter
    
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("hello there")
        data = {
            "User_Name": json_data["User_Name"],               
            "User_Id":json_data["User_Id"],
            "Mobile": json_data["Mobile"]            
        }
        User_Name=data["User_Name"]
        User_Id=data["User_Id"]
        Mobile=data["Mobile"]
        
        mycol = user_management
        mappedcol = Mapped_Route_Management
        answered_col = Storing_Answers_To_Checklist
        
        deleted_answers = []
        deleted_user = []
        delete_user_list = []
        mycol.objects.filter(User_Name=User_Name,Mobile=Mobile).delete()
        for dict in mycol.objects.filter(User_Name=User_Name,Mobile=Mobile):
                delete_user_list.append(dict)
                
        mappedcol.objects.filter(USER_NAME=User_Name).delete()
        for dictionary in mappedcol.objects.filter(USER_NAME=User_Name):
                deleted_user.append(dictionary)
                
        answered_col.objects.filter(UserID=User_Id).delete()        
        for dictionary in answered_col.objects.filter(UserID=User_Id):
                deleted_answers.append(dictionary)

        if len(delete_user_list) != 0:
            response = {"Status":200,
                        "Deleted Collection":delete_user_list}
        elif len(deleted_user) != 0:
            response = {"Status":200,
                        "Deleted Collection":deleted_user}
        elif len(deleted_answers) != 0:
                response = {"Status":200,
                "Deleted Answers":deleted_answers} 
        else:
            response = {"Status":500,
                        "Message": "Data Not Found"}
        
    # return response
        
        # URL = f"http://127.0.0.1:65/VGT/Delete_Added_User_From_Add_page_info/{User_Name},{User_Id},{Mobile}"
        # resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
        # print("output of r:", resp)
        # try:
        #     paste_url = response["Status"]                      
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(paste_url)
    return JsonResponse({'success': False})


#@***************get_user_management_info***************@
def get_user_management_info(request):
    # response = requests.get("http://127.0.0.1:65/VGT_get_user_management_info/")
    print("API Response has been stored")  
    # data = response.json()  
    from vgtapp.models import user_management
    list_of_users = []
    user_data = user_management.objects.all()
    
    for dics in user_data:
        list_of_users.append({
        "User_Name": dics.User_Name,
        "userID": dics.userID,
        "Site_Name": dics.Site_Name,
        "Site_Code": dics.Site_Code,
        "Designation": dics.Designation,
        "Mobile": dics.Mobile,
        "Email": dics.Email,
        "Admin_UserID": dics.Admin_UserID,
        "Password": dics.Password,
        "Date_Registration": dics.Date_Registration
        })
    
    return JsonResponse(list_of_users, safe=False)
 
#@***************Route_Management***************@
def Route_Management(request):
    # response= requests.get("http://127.0.0.1:65/VGT/Route_Management/")
    # data = response.json()
    # print(type(data))
    
    user_id_list = ''
    '''
    data base start declearing 
    -----------------------------------------------------------
    '''
    from vgtapp.models import site_management,Route_Management,Camera_info,Route_Management_info

    route_info = Route_Management_info
    site_col = site_management
    route_col = Route_Management
    camera_col = Camera_info
    '''--------------------------------------------'''
    Admin_id = ""
    route_collections = route_col.objects.all()
    route_info_collections = route_info.objects.all()
    site_collection = site_col.objects.all()
    route_list = []
    site_list = []
    user_id_list = []
    site_admin_list = []
    route_site_list = []
    route_admin_id_list = []
    route_route_list = []
    route_admin_route_list = []
    '''-----------------------------------------------'''
    # def Route_info():   
    # try: 
    print("472!!!")
    print("asdf")
    '''---Getting the route information----'''
    for site in route_collections:
        route_site_list.append(site.Site_Name)
        route_route_list.append(site.Route_Name)
        #admin_id
    
    '''-----Getting the route management information-------'''
    for routes in route_info_collections:
        route_list.append(routes.Route_Name)
        site_list.append(routes.Site_Name)
    # print("The route list is:",route_list)
    for site_dict in site_collection: 
        for route_dict in route_col.objects.filter(Site_Name = site_dict.Site_Name):                
            Route_name = route_dict.Route_Name
            site_name = route_dict.Site_Name 

            # print("Route name 331:",Route_name)
            # print("Site name 332:",site_name)
            if Route_name not in route_list :
                data_found_for_that_site = camera_col.objects.filter(Site_Name=site_name)
                
                try:
                    for dicts in data_found_for_that_site:
                        
                        Admin_id = dicts.Admin_unique_id
                        # print("I am at line 496!",Admin_id)
                        
                except Exception as e:
                    print("error is:",e)
                
                # print("the site dict is:",site_dict)
                info = {
                        "Route_Name": Route_name,
                        "Site_Name": site_dict.Site_Name,
                        "Site_Code": site_dict.Site_Code,
                        "Region": site_dict.Region,
                        "Branch": site_dict.Branch,
                        "Admin_id" : site_dict.Admin_id
                    } 
                info["No_Of_Camera"] = len([values for values in data_found_for_that_site])
                
                user_id_count = len([docs for docs in route_info.objects.all()])
                # print("The user id count is at line 516:",user_id_count)

                if user_id_count == 0:
                            info["user_id_count"] = 1
                else:
                    for dictionary in route_info.objects.all():  
                        user_id = dictionary.user_id_count
                        user_id_list.append(user_id)
                        # print("The user count is:",user_id_list)
                info["user_id_count"] = len(user_id_list) + 1
                
                # print("Filtered_camera_records:",site_name,len([values for values in data_found_for_that_site]))
                # count_of_camera_for_site = len([values for values in data_found_for_that_site])

                # "No_Of_Camera": len([values for values in data_found_for_that_site])                  
                # route_info.insert_one(info)  # Insert the list of information into the collection
                route_data = route_info.objects.create(
                        Route_Name = info["Route_Name"],
                        Site_Name = info["Site_Name"], 
                        Site_Code = info["Site_Code"], 
                        Region = info["Region"],  
                        Branch = info["Branch"] , 
                        Admin_id = info["Admin_id"] , 
                        No_Of_Camera = info["No_Of_Camera"] , 
                        user_id_count = info["user_id_count"]  
                )
                print("info",info)
                route_data.save()
            else:
                print(f"Route already present! {Route_name} {site_name}")
    # except Exception as e:
    #     return {"Error": e}
    # Route_info()    
    # doc = json.loads(route_information.objects().to_json())
    # return doc
    list_of_routes = []
    
    for docs in route_info.objects.all():
        list_of_routes.append(
        {
        "Route_Name": docs.Route_Name ,
        "Site_Name": docs.Site_Name,
        "Site_Code": docs.Site_Code,
        "Region": docs.Region,
        "Branch": docs.Branch,
        "Admin_id": docs.Admin_id,
        "No_Of_Camera": docs.No_Of_Camera,
        "user_id_count": docs.user_id_count
        })
    print("The list of routes are:",list_of_routes)
    return JsonResponse(list_of_routes, safe=False)


# #@***************Update_VGT_Route_Managementinfo***************@
@csrf_exempt
def vgt_updateroute_info(request):
    from vgtapp.models import Route_Management_info,site_management,Route_Management
    # print("Request received")
    data = {}
    # URL = 'http://127.0.0.1:65/VGT/VGT_Update_Route_Management_info/'      
    if request.method == "PUT":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "user_id_count": json_data["user_id_count"],
            "Admin_id": json_data["Admin_id"],
            "site_name": json_data["site_name"],
            "Site_Code": json_data["Site_Code"],
            "Route_Name": json_data["Route_Name"],
            "Region": json_data["Region"],
            "Branch": json_data["Branch"],                     
        }       
        Admin_id = data["Admin_id"]
        Site_name = data["site_name"]
        Site_code = data["Site_Code"]
        Route_name = data["Route_Name"]
        Region = data["Region"]
        Branch = data["Branch"]
        user_id = data["user_id_count"]


        mydb = Route_Management_info
        site_col = site_management
        route_col = Route_Management
        saved_management_info_list= []

        for dictionary in mydb.objects.filter(user_id_count=user_id):
            saved_management_info_list.append(dictionary)
        
        updated_Routename_route_col = {
                            "Route_Name":Route_name
                        }
        
        update_Region_Branch_site_col = {
            "Region" : Region,
            "Branch" : Branch
        }
        
        update_Region_Branch_Route_Managementinfo_col ={
            "Region" : Region,
            "Branch" : Branch,
            "Route_Name" : Route_name
        }
        
        if len(saved_management_info_list)!=0:
            # print("The line 1023!")
            route_col.objects.filter(admin_id=Admin_id,Site_Name=Site_name).update(Route_Name=Route_name)
            # for x in route_col.objects.filter(admin_id=Admin_id,Site_Name=Site_name):
            #     x.objects.update(
            #         {"admin_id":Admin_id,"Site_Name":Site_name},
            #         {'$set': updated_Routename_route_col}
            #     )
            # print("The line 1030!")
            site_col.objects.filter(Admin_id=Admin_id,Site_Name=Site_name,Site_Code=Site_code).update(Region = Region,
            Branch = Branch)    
            # for x in site_col.objects.filter(Admin_id=Admin_id,Site_Name=Site_name,Site_Code=Site_code):       
            #     result = site_col.update_one(
            #         {"Admin_id":Admin_id,"Site_Name":Site_name,"Site_Code":Site_code},
            #         {'$set': update_Region_Branch_site_col}
            #     ) 
            # print("The line 1038!")
            mydb.objects.filter(user_id_count=user_id).update(Region=Region,Branch =Branch,Route_Name= Route_name)    
            # for x in mydb.objects.filter({"user_id_count":user_id}):           
            #     result = mydb.update_one(
            #         {"user_id_count":user_id},
            #         {'$set': update_Region_Branch_Route_Managementinfo_col}
            #     )
            return_status = {"Status":200}
        else:
            return_status = {"Status":500}
        # return return_status
        
 
        # r = requests.put(url=URL, json=data)        
        # try:
        #     paste_url = return_status.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(return_status)
    return JsonResponse(return_status)

# #@***************VGT_Delete_route_site_name***************@

# #---685-707---#

@csrf_exempt
def delete_route_site_name(request):
   
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("hello there")
        data = {
            "Route_name": json_data["Route_name"],  
            "Site_name": json_data["Site_name"],
        }
        route_name=data["Route_name"]
        site_name=data["Site_name"]
        # print("jitesh",site_code,site_name)
        # URL = f"http://127.0.0.1:65/VGT/VGT_Delete_Route_Management/{route_name},{site_name}"
        # resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
        from vgtapp.models import Route_Management_info,Route_Management
        route_info = Route_Management_info
        route_col = Route_Management
        route_data = []
        
        route_collections = route_col.objects.filter(Route_Name=route_name,Site_Name=site_name).delete()
        route_info_collections = route_info.objects.filter(Route_Name=route_name,Site_Name=site_name).delete()

        route_list = []
        site_list = []
        site_admin_list = []
        route_site_list = []
        route_admin_id_list = []
        route_route_list = []
        route_admin_route_list = []
        '''-----------------------------------------------'''

        # def Route_info():   
        try: 
            print("472!")
            '''---Getting the route information----'''
            route_col.objects.filter()
            for docs in route_collections:           
                route_route_list.append(docs)
                
            
            '''-----Getting the route management information-------'''
            for route_docs in route_info_collections:
                route_list.append(route_docs)
                
        except Exception as e:
            print("Errors found while appending the documents:",e)
            
        if len(route_list) != 0 and len(route_route_list) != 0:
            rt = {"Status": 200, "Message":"Data Found"}
        else:
            rt = {"Status":500,"Message":"Data Not Found"}
    # return rt 

        print("output of r:", rt)
        # try:
        #     paste_url = rt.text                      
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(rt["Status"])
    return JsonResponse({'success': False})
'''---------------------------- 25/05/2024 Binding should be done. -------------------------------'''
# @csrf_exempt
# def delete_route_site_name(request,Route_name,Site_name):
#     URL = f"http://69.30.247.220:80:65/VGT/VGT_Delete_Route_Management/{Route_name},{Site_name}"
#     data = {}
#     if request.method == "DELETE":  # Change the condition to check for DELETE method
#         json_data = json.loads(request.body.decode('utf-8'))
#         print("hello there")
#         data = {
#             "Route_name": json_data["Route_name"],   
#             "Site_name": json_data["Site_name"],
#         }
#         resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
#         print("output of r:", resp)
#         try:
#             paste_url = resp.text
#             # print("jitesh"+resp.Status)
#             # print(type(paste_url))
#             # print("The paste_url is: %s" % paste_url)            
#             return HttpResponse(paste_url)
#         except Exception as e:
#             print(resp.Status)
#     return JsonResponse({'success': False})

# #@***************get_user_info_in_dashboard***************@
@csrf_exempt
def user_info_dashboard(request,User_Name):
    print("I am at line 1231!")
    import ast
    
    # Assuming 'u_name' is from the query parameters
    # u_name = request.GET.get('u_name', '')  # Get 'u_name' from the query parameters, defaulting to an empty string if not found
    # print("The user names",User_Name,u_name)
    # base_url = f"http://127.0.0.1:65/VGT_get_user_info_in_dashboard/{User_Name}"
    # # base_url = f"http://69.30.247.220:80:65/VGT_get_user_info_in_dashboard/{User_Name}?u_name="
    # url_with_site = f"{base_url}?u_name={u_name}"
    # # url_with_site = base_url.replace('{User_Name}', u_name)
    # print("url_with_site:", url_with_site)
    
    unique_user = ""

    myuser = user_management
    mymap = Mapped_Route_Management
    store_answer_db = Storing_Answers_To_Checklist

    dict3 = {}
    # dict4 = {}

    '''---variable used for camera db---'''
    #get_site_name =[]
    #get_camera_name =[]

    '''---variable used for Mapped_Route_Management db--'''
    get_user_name = []
    get_site_name = []
    get_route_name = []
    #get_scheduled_time = []
    get_start_time = []
    get_end_time = []
    
    get_camera_name = []

    '''---variable used for user_management db--'''
    get_ph_no = []

    '''Getting the Admin id for the given user name'''
    admin_id_for_the_user = [dictionarys.Admin_UserID for dictionarys in myuser.objects.filter(User_Name=User_Name)]
    
    print("The admin id :",admin_id_for_the_user)
    
    for dicts in store_answer_db.objects.filter(Admin_id = int(admin_id_for_the_user[0])):
        print("The stored answered :",dicts.Admin_id,dicts.Registered_Camera_Answer_Response)

    
    '''--fetching info from Mapped_Route_Management db with the given site_name---'''
    for x in mymap.objects.filter(USER_NAME = User_Name):
        # print("Document responds is:",x)
        get_user_name.append(x.USER_NAME)
        unique_user = set(get_user_name)
        get_site_name.append(x.Site_Name)
        # unique_site_name = set(get_site_name)
        get_route_name.append(x.Route_Name)   
        #get_scheduled_time.append(x['Schedule_Time'])      
        get_start_time.append(x.Start_Date_Time)  
        get_end_time.append(x.End_Date_Time)    
        get_camera_name.append(x.Camera_Name)
        # unique_camera_name = set(get_camera_name)
    
    '''
        Getting the endtime from the stored answered database
    '''
    
    stored_endtime_list = []
    for user,site,route,camera in list(zip(get_user_name,get_site_name,get_route_name,get_camera_name)):
        print({"User_name":user,"Site_Name":site,"Route_Name":route,"camera_name":camera})
        
        count_of_docs_for_stored_answers = len([docs for docs in store_answer_db.objects.filter(User_name = user,Site_Name = site,Route_Name = route,camera_name = camera[0])])
        if count_of_docs_for_stored_answers != 0:    
            for dictionaries in store_answer_db.objects.filter(User_name = user,Site_Name = site,Route_Name = route,camera_name = camera[0]):
                stored_endtime_list.append(dictionaries.End_time)
        else:
            stored_endtime_list.append("")
    print("The endtime list is:",stored_endtime_list)  
    
    endtime_stored_data = {
                "End_time" : stored_endtime_list
                        }
    
    from_mapped_route_db = {
                    "USER_NAME": unique_user,
                    "Site_Name": get_site_name,
                    "Route_Name": get_route_name,
                    #"Schedule_Time": get_scheduled_time,
                    "Start_Time": get_start_time,
                    "End_Time"  : get_end_time,
                    "Camera_Name": get_camera_name
                }
    
    '''--fetching info from user_management db with the given site_name---'''
    for x in myuser.objects.filter(User_Name= User_Name):
        get_ph_no.append(x.Mobile)
    from_user_management_db = {                           
                                "Mobile": get_ph_no
                              }
    
    '''---merging 'from_cam_db' and 'from_mapped_route_db' -----'''
    def Merge(dict1, dict2):
        res = {**dict1, **dict2}
        return res
    
    dict2 = Merge(from_mapped_route_db,from_user_management_db)

    dict3 = Merge(dict2,endtime_stored_data)
    # return dict3
    # response = requests.get(url_with_site)
    # print("url_with_site:",url_with_site)
    data = dict3
    '''
    Filtering the user data and camera data.
    '''
    print("The user data:",data)  
    
    camera_data = data['Camera_Name']
    if len(camera_data)>0:
        converted_camera_data = ast.literal_eval(camera_data[0])  
        camera_data = [converted_camera_data]
        data["Camera_Name"] = camera_data
    else:
        data["Camera_Name"] = []
    
    user_data = data["USER_NAME"]
    print("The user data:",list(user_data),user_data)
    data["USER_NAME"] = list(user_data)
    print("The camera data:",camera_data)
    print("The json data",data)
    
    '''
    {'USER_NAME': ['Test Guard'], 'Site_Name': ['SIS_Site_One', 'SIS_Site_One'], 
    'Route_Name': ['Test_Route_One', 'Test_Route_Four'], 'Start_Time': ['5/24/24 6:54pm', '5/28/24 2:54pm'], 
    'End_Time': ['5/24/24 9:54pm', '5/28/24 4:55pm'], 'Camera_Name': [['Front_Camera'], 
    ['Front_Camera']], 'Mobile': ['9573092310'], 'End_time': ['16:55:02', '']}
    '''
    
    '''
    {'USER_NAME': {'Test Guard'}, 'Site_Name': ['SIS_Site_One'], 'Route_Name': ['Test_Route_One'], 
    'Start_Time': ['5/28/24 2:23pm'], 'End_Time': ['5/28/24 7:23pm'], 'Camera_Name': ["['Front_Camera']"], 
    'Mobile': ['9573092000'], 'End_time': ['']}
    '''
    
    return JsonResponse({"data":data, "safe":False})

# # def user_info_dashboard(request):
# #     response= requests.get("http://69.30.247.220:80:65/VGT_get_user_info_in_dashboard/")
# #     data = response.json()
# #     print(type(data))
# #     return JsonResponse(data, safe=False)

# # @***************vgt_add_site***************@
@csrf_exempt
def vgt_add_site(request):
    # print("Request received")
    data = {}
    # URL = 'http://127.0.0.1:65/VGT_Add_Site/'      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        import vgtapp.add_site as ad
        print("The json data:",json_data)
        data = {            
            "Site_Name": json_data["Site_Name"],
            "Site_Code": json_data["Site_Code"], 
            "Region": json_data["Region"],
            "Branch": json_data["Branch"],                       
            "Admin_id": json_data["Admin_id"],
            "zone":json_data["zone"]
        }        
        req = ad.adding_site(data)        
        # try:
        #     paste_url = req["statusCode"]
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print("status_code",500)
    return JsonResponse({'success': False})

#@***************VGT_get_site_name/site_code***************@
def get_site_name_code(request):
    # response= requests.get("http://127.0.0.1:65/VGT/get_siteName_siteCode/")
    # data = response.json()
    site_data = site_management.objects.all()
    list_of_sites = []
    for sites in site_data:
        list_of_sites.append(
        {
            "Site_Name": sites.Site_Name,
            "Site_Code": sites.Site_Code,
            "Region": sites.Region,
            "Branch": sites.Branch,
            "Admin_id": sites.Admin_id,
            "Zone": sites.Zone,
            "No_Route": sites.No_Route,
            "is_action": sites.is_action,
            "No_Of_Camera": sites.No_Of_Camera
        })

    return JsonResponse(list_of_sites, safe=False) 

#@***************VGT_Delete_site_code_name***************@
@csrf_exempt
def Delete_site_code_name(request):
   
    data = {}
    if request.method == "DELETE":  # Change the condition to check for DELETE method
        json_data = json.loads(request.body.decode('utf-8'))
        print("hello there")
        print("The json result is:",json_data)
        data = {
            "Site_Name": json_data["Site_Name"],  
            "Site_Code": json_data["Site_Code"],
             "Admin_id": json_data["Admin_id"],
        }
        Site_Name=data["Site_Name"]
        Site_Code=data["Site_Code"]
        Admin_id=data["Admin_id"]
        print("The admin id:",Admin_id,type(Admin_id))
        # print("jitesh",site_code,site_name)
        # URL = f"http://127.0.0.1:65/VGT_Delete_Site/{site_name},{site_code},{admin_id}"
        # resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
        # print("output of r:", resp)
        from vgtapp.models import Route_Management
        site_mycol = site_management
        route_col = Route_Management
        route_managment_col = Route_Management_info #Site_Name #Site_Code
        user_management_col = user_management #Site_Name #Site_Code
        camera_col = Camera_info #Site_Name #Site_Code
        Mapped_Route_Management_col = Mapped_Route_Management
        check_list_col = check_list
        image_col = Saving_Image_DB
        mp4_col = Saving_mp4_DB
        user_col = user_data
        store_checklist_col = Storing_Answers_To_Checklist
        report_for_sitename_col = Report_for_particular_sitename
        
        Deleted_saved_list = []
        camera_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_unique_id=int(Admin_id)).delete()
        for dicts in camera_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_unique_id=int(Admin_id)):
            Deleted_saved_list.append(dicts)
            # camera_col.objects.delete(dicts)
        
        site_mycol.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_id=int(Admin_id)).delete()
        for dicts in site_mycol.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_id=int(Admin_id)):
            Deleted_saved_list.append(dicts)
            # site_mycol.objects.delete(dicts)      
        
        Mapped_Route_Management_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_UserID=(Admin_id)).delete()
        for dicts in Mapped_Route_Management_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_UserID=(Admin_id)):
            Deleted_saved_list.append(dicts)
            # Mapped_Route_Management_col.objects.delete(dicts)
        
        route_col.objects.filter(Site_Name=Site_Name,admin_id=Admin_id).delete()
        for dicts in route_col.objects.filter(Site_Name=Site_Name,admin_id=Admin_id):
            Deleted_saved_list.append(dicts)
            # route_col.objects.delete(dicts)      
        
        check_list_col.objects.filter(Site_Name=Site_Name,Admin_UserID=Admin_id).delete()
        for dicts in check_list_col.objects.filter(Site_Name=Site_Name,Admin_UserID=Admin_id):
            Deleted_saved_list.append(dicts)
            # check_list_col.objects.delete(dicts)    
        
        route_managment_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_id=Admin_id).delete()
        for dicts in route_managment_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_id=Admin_id):
            Deleted_saved_list.append(dicts)
            # route_managment_col.objects.delete(dicts)

        user_management_col.objects.filter(Site_Name=Site_Name,Site_Code=Site_Code,Admin_UserID=Admin_id).delete()
        for dicts in user_management_col.objects.filter(Admin_UserID=Admin_id):
            Deleted_saved_list.append(dicts)
            # user_management_col.objects.delete(dicts)
        print("The length of the list is :",len(Deleted_saved_list),Deleted_saved_list)
        
        image_col.objects.filter(site_name=Site_Name,admin_id=int(Admin_id)).delete()
        for dicts in image_col.objects.filter(site_name=Site_Name,admin_id=int(Admin_id)):
            print("The data in the dictionary is:",dicts)
            Deleted_saved_list.append(dicts)
            # image_col.objects.delete(dicts)
        
        mp4_col.objects.filter(site_name=Site_Name,admin_id=int(Admin_id)).delete()
        for dicts in mp4_col.objects.filter(site_name=Site_Name,admin_id=int(Admin_id)):
            Deleted_saved_list.append(dicts)
            # mp4_col.objects.delete(dicts)
        
        user_col.objects.filter(Site_Name=Site_Name,Admin_id=Admin_id).delete()
        for dicts in user_col.objects.filter(Site_Name=Site_Name,Admin_id=Admin_id):
            Deleted_saved_list.append(dicts)
            # user_col.objects.delete(dicts)
        print("The list of deleted data:",Deleted_saved_list)
        
        #store_checklist_col
        store_checklist_col.objects.filter(Site_Name=Site_Name,Admin_id=int(Admin_id)).delete()
        for dicts in store_checklist_col.objects.filter(Site_Name=Site_Name,Admin_id=int(Admin_id)):
            Deleted_saved_list.append(dicts)
            # store_checklist_col.objects.delete(dicts)
        print("The list of deleted data:",Deleted_saved_list)
        
        report_for_sitename_col.objects.filter(Site_Name=Site_Name,admin_Id=Admin_id).delete()
        for dicts in report_for_sitename_col.objects.filter(Site_Name=Site_Name,admin_Id=Admin_id):
            Deleted_saved_list.append(dicts)
            # report_for_sitename_col.objects.delete(dicts)
        print("The list of deleted data:",Deleted_saved_list)
        
        if len(Deleted_saved_list)!=0:
            responses = {"Status":200}
        else:
            responses = {"Status":500,
                        "Message":"Data Not Found"}

        # try:
        #     paste_url = responses                   
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(responses["Status"])
    return JsonResponse({'status_code': responses["Status"]})

# #ENENT MANAGEMENT#
# #@***************Get_VGT_Answers_to_Checklist***************@
def get_vgt_ans_checklist(request):
    # response= requests.get("http://127.0.0.1:65/VGT/VGT_Answers_To_Checklist/")
    mydb = Storing_Answers_To_Checklist
    cursor = mydb.objects.all()
    saved_doc = []
    
    for doc in cursor:
        
        docs = {
        "Questions": doc.Questions,
        "Answers": doc.Answers ,
        "Issues": doc.Issues,
        "Description": doc.Description,
        "Incident": doc.Incident,
        "Code": doc.Code,
        "Priority": doc.Priority,
        "Site_Name": doc.Site_Name,
        "Admin_id": doc.Admin_id,
        "UserID": doc.UserID,
        "User_name": doc.User_name,
        "Route_Name": doc.Route_Name,
        "camera_name": doc.camera_name,
        "Schedule_time": doc.Schedule_time ,
        "End_time": doc.End_time ,
        "Imagestring": doc.Imagestring,
        "Upload_photo_video_Image_string": doc.Upload_photo_video_Image_string,
        "Registered_Camera_Answer_Response": doc.Registered_Camera_Answer_Response
        }
        saved_doc.append(docs)

    return JsonResponse({"data":saved_doc,"success":False})

# #@***************POST_VGT_Answers_to_Checklist***************@   
@csrf_exempt
def vgt_ans_checklist(request):
    # print("Request received")
    data = {}
    # URL = 'http://127.0.0.1:65/VGT/VGT_Answers_To_Checklist/'
    mydb = Storing_Answers_To_Checklist      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        print("The json_data:",json_data)
        data = {            
            "Questions": json_data["Questions"],
            "Answers": json_data["Answers"],
            "Admin_ID": json_data["Admin_ID"], 
            "Issues": json_data["Issues"],
            "Description": json_data["Description"],       
            "Incident": json_data["Incident"],
            "Code": json_data["Code"],
            "Priority": json_data["Priority"],
            "UserID": json_data["UserID"],
            "User_Name":json_data["User_Name"],
            "Site_Name":json_data["Site_Name"],
            "Route_Name": json_data["Route_Name"],
            "camera_name": json_data["camera_name"],
            "Schedule_time": json_data["Schedule_time"],
            "End_time" : json_data["End_time"],
            "Upload_photo_video_Image_string": json_data["Upload_photo_video_Image_string"]
        }        
        # r = requests.post(url=URL, json=data)
                
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
        mydb.objects.create(
            Questions = data["Questions"],
            Answers = data["Answers"],
            Issues = data["Issues"],
            Description = data["Description"],
            Incident = data["Incident"],
            Code = data["Code"],
            Priority = data["Priority"],
            Site_Name = data["Site_Name"],
            Admin_id = data["Admin_ID"],
            UserID = data["UserID"],
            User_name = data["User_Name"],
            Route_Name = data["Route_Name"],
            camera_name = data["camera_name"],
            Schedule_time = data["Schedule_time"],
            End_time = data["End_time"],
            # Imagestring = data[""],
            Upload_photo_video_Image_string = data["Upload_photo_video_Image_string"],
            # Registered_Camera_Answer_Response = data[""] 
        )
    return JsonResponse({'success': False})


# #-Imagepath-@#

# #@***************Vgt_getimagepath***************@
# def get_vgt_imagepath(request):
#     response= requests.get("http://127.0.0.1:65/VGT/Get_Imagepath/")
#     data = response.json()
#     print(type(data))
#     return JsonResponse(data, safe=False)

# #@***************Vgt_captureimage***************@   
@csrf_exempt
def post_vgt_captureimage(request):
    # print("Request received")
    data = {}
    URL = 'http://127.0.0.1:65/VGT/Capture_Image/'      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {          
            "rtsp_link": json_data["rtsp_link"],
            "admin_id": json_data["admin_id"],
            "user_name":json_data["user_name"],
            "user_id":json_data["user_id"],
            "site_name": json_data["site_name"],
            "camera_name": json_data["camera_name"],
            "Route_name": json_data["Route_name"],
        }
        # r = requests.post(url=URL, json=data)        
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
        from vgtapp.saving_image_api import capture_image
   
   # if capimagedata.rtsp_link != "string":
        capture_response = capture_image(data["rtsp_link"],data["admin_id"],
                        data["user_name"],data["user_id"],data["site_name"],
                        data["camera_name"],data["Route_name"])
        print(capture_response)
        response = capture_response
        if response == 200:
            doc = {"Status": 200}
        else:
            doc = {"Status": 500,"Message":"Enter RTSP link"}
        
    return JsonResponse({'Data':doc,'success': False})


# #-Mp4path-@#

# #@***************get_vgt_Mp4path***************@
# def get_vgt_Mp4path(request):
#     response= requests.get("http://127.0.0.1:65/VGT/Get_Imagepath_Mp4/")
#     data = response.json()
#     print(type(data))
#     return JsonResponse(data, safe=False)

# #@***************Vgt_capturemp4***************@   
@csrf_exempt
def post_vgt_captureMp4(request):
    # print("Request received")
    Saving_mp4_DB
    data = {""}
    # URL = 'http://127.0.0.1:65/VGT/Capture_Mp4/'      
    if request.method == "POST":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {          
            "rtsp_link": json_data["rtsp_link"],
            "admin_id": json_data["admin_id"],    
            "user_name":json_data["user_name"],
            "user_id":json_data["user_id"],
            "site_name":json_data["site_name"],
            "camera_name": json_data["camera_name"],
            "Route_name": json_data["Route_name"],
        }
        # r = requests.post(url=URL, json=data)        
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
        mp4_data = Saving_mp4_DB.objects.create(
        rtsp_link  = data["rtsp_link"], 
        admin_id  = data["admin_id"],
        user_name = data["user_name"], 
        user_id   = data["user_id"], 
        # image_path = data[""], 
        # site_name = data[""],
        # camera_name  = data[""], 
        Route_Name  = data["Route_name"], 
        # Datetime  = data[""],
        )
        mp4_data.save()
        print("Saved the mp4 data!")
        return JsonResponse({'success': False})

# #@***************VGT_Eventsimagepath***************@
# def get_eventsimgpath(request):
#     response= requests.get("http://127.0.0.1:65/GetEventImagesPath/")
#     data = response.json()
#     print(type(data))
#     return JsonResponse(data, safe=False)


# #@***************VGT_Weekly_Patrolling_Completed_Pending_Report***************@  
def vgt_patrolling_report(request,adminid):
    # Assuming 'u_name' is from the query parameters
    # Admin_UserID = request.GET.get('Admin_UserID','')  # Get 'admin_id' from the query parameters, defaulting to an empty string if not found

    from vgtapp.weekly_patrolling_complete_pending_report import completed_pending_report
    return_data = completed_pending_report(adminid)
   
    data = return_data
    print("The weekly partrol data:",data)
    return JsonResponse(data) 


# #@***************VGT_weekly_report***************@  
def vgt_weekly_report(request,admin):
    # Assuming 'u_name' is from the query parameters
    # Admin_UserID = request.GET.get('Admin_UserID','')  # Get 'admin_id' from the query parameters, defaulting to an empty string if not found
   
    # base_url = f"http://127.0.0.1:65/VGT/VGT_Weekly_Report/"    
    # url_with_site = f"{base_url}?{admin}"  
    # print("url_with_site_weekly:", url_with_site)    
    # response = requests.get(url_with_site)
    # print("url_with_site:",url_with_site)
    
  
    mydb = Storing_Answers_To_Checklist
    user_database = user_management
    storage_of_Adminids = []
    storage_of_answered_question_count_list = []
    
    from vgtapp import get_start_end_date
    startdate_of_week, enddate_of_week = get_start_end_date.takes_given_date_return_start_end_date()
    
    ''''''
    start_date_list = startdate_of_week.split("/")
    start_day,start_month,start_year =int(start_date_list[0]),int(start_date_list[1]),int(start_date_list[2])
    
    End_date_list = enddate_of_week.split("/")
    End_day,End_month,End_year =int(End_date_list[0]),int(End_date_list[1]),int(End_date_list[2])
    
    # Define start and end dates   
    start_date = datetime(start_year, start_month, start_day)
    end_date = datetime(End_year, End_month, End_day)

    date_difference = end_date - start_date
    # Generate a list of dates within the range
    date_list = [(start_date + timedelta(days=x)).strftime("%d/%m/%Y") for x in range(date_difference.days + 1)]
    ''''''
    # print("The date list is:",date_list)
    
    for dictionary in user_database.objects.filter(Admin_UserID = admin):
        storage_of_Adminids.append(dictionary["Admin_UserID"])
    print("The storing adminids are:",storage_of_Adminids)
    for adminid in set(storage_of_Adminids):
        for date in date_list:
            for dicts in  mydb.objects.filter(Admin_id = int(adminid),Registered_Camera_Answer_Response = date):
                # print("The dicts are:",dicts["Admin_id"],dicts["Registered_Camera_Answer_Response"])
                storage_of_answered_question_count_list.append(dicts)
    print("the list of answers:",storage_of_answered_question_count_list)
    count_of_answered_Question_for_that_week =  len(storage_of_answered_question_count_list)
    
    message = {"Count":count_of_answered_Question_for_that_week}

    data = message   
    return JsonResponse(data)  
    # return JsonResponse(data, safe=False)    

# #@***************VGT_Daily_report***************@
def vgt_daily_report(request,admin):
    '''
    Daily report for the given admin id.
    '''
    mydb = Storing_Answers_To_Checklist
    user_database = user_management
    storage_of_Adminid = []
    storage_of_answered_question_count_list = []
    
    for dictionary in user_database.objects.filter(Admin_UserID = admin):
            storage_of_Adminid.append(dictionary.Admin_UserID)
    
    # print("Storage of adminids:",storage_of_Adminid)
    
    date = datetime.now().strftime("%d/%m/%Y")
    for Adminid in storage_of_Adminid:
        for dicts in  mydb.objects.filter(Admin_id = int(Adminid),Registered_Camera_Answer_Response = date):
            storage_of_answered_question_count_list.append(dicts)

    message = {"Count":len(storage_of_answered_question_count_list)}
    
    data = message
   
    # return JsonResponse(data, safe=False)
    return JsonResponse(data)


# #@***************get_vgt_monthly_report***************@
def get_vgt_monthly_report(request,Admin_UserID):
    # Assuming 'u_name' is from the query parameters
    # Admin_UserID = request.GET.get('Admin_UserID','')  # Get 'admin_id' from the query parameters, defaulting to an empty string if not found
   
    # base_url = f"http://127.0.0.1:65/GetMonthlyReport/"    
    # url_with_site = f"{base_url}{Admin_UserID}"  
    # print("url_with_site_monthly:", url_with_site)    
    # response = requests.get(url_with_site)
    # print("url_with_site:",url_with_site)
    '''
    Montly report for the given admin id.
    '''
    
    from vgtapp import monthly_report_1 as mr
    from collections import Counter
 
    mr.information()
   
    # Connect to MongoDB
    mycol = monthly_weekly_incident
    user_database = user_management
    storage_of_adminid = []
    month_list = []
    
    for dictionary in user_database.objects.filter(Admin_UserID = Admin_UserID):
            storage_of_adminid.append(dictionary.Admin_UserID)
 
    for adminid in set(storage_of_adminid):
        for x in mycol.objects.filter(Admin_UserID=int(adminid)):
            print("The values in the collection is:",x)
            month = x.Incident_Month
            month_list.append(month)
            print(x)
    print('month list:',month_list)
   
    # Count occurrences of each month
    month_counts = dict(Counter(month_list))
 
    # Create a dictionary with all months initialized to 0
    all_months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    result = {month: month_counts.get(month, 0) for month in all_months}
 
    # # Display counts for all months
    # for month, count in result.items():
        # print(f"{month} = {count}")
   
    mycol.objects.all().delete()
 

    data = result
   
    # return JsonResponse(data, safe=False)
    return JsonResponse(data)

# #@***************GetReport_nonparameterized***************@
def siten_adminid_routen(request):
    '''
    Need to get Admin_id,Site_Name,Route_Name,Start_Date,End_Date from the 
    front end.
    '''
    from vgtapp.get_all_generate_report_data import get_countof_events
    result = get_countof_events()
    print("The result at line 1786:",result)

    # if request.method == "GET":
        # json_data = json.loads(request.body.decode('utf-8'))
        # print("The siten_adminid_routen json data:",json_data)
    # response= requests.get("http://127.0.0.1:65/VGT/Generate_Report_For_Sitename,adminID,routeName/")
    # from datetime import datetime, timedelta
    # from vgtapp.models import Report_for_particular_sitename
    # mycol = Report_for_particular_sitename
    # results = []
    # from generate_report_for_adminid import get_countof_events
    # result = get_countof_events(Start_Date,End_Date)
    
    # start_date_list = Start_Date.split("/")
    # start_day,start_month,start_year =int(start_date_list[0]),int(start_date_list[1]),int(start_date_list[2])
    # # print("The start day,month,year:",start_day,start_month,start_year)
    # End_date_list = End_Date.split("/")
    # End_day,End_month,End_year =int(End_date_list[0]),int(End_date_list[1]),int(End_date_list[2])
    
    # # Define start and end dates   
    # start_date = datetime(start_year, start_month, start_day)
    # end_date = datetime(End_year, End_month, End_day)
    # # print('The start date:',start_date,end_date)
    # # Calculate the difference between end and start dates
    # date_difference = end_date - start_date
    # # print("The date difference is:",date_difference)

    # # Generate a list of dates within the range
    # date_list = [(start_date + timedelta(days=x)).strftime("%d/%m/%Y") for x in range(date_difference.days + 1)]

    # result_list = []
    # # print("The list of dates are:",date_list)
    # for dates in date_list:
    #     docs = mycol.find({
    #                 "admin_Id":Admin_id,
    #                 "Site_Name":Site_Name,
    #                 "Route_Name":Route_Name,
    #                 "Date_Of_CameraRegistration": dates
    #                 },{"_id":0})
    #     for dictionary in docs:
    #         # print("The dictionaries in the mycol is:",dictionary)
    #         #appending the docs in the result_list
    #         result_list.append(dictionary)
    # # print("The result list is:",result_list)

    # data = result_list
    
    return JsonResponse({'Data':result,'success': False})


# #@***************GetReport_parameterized***************@
# def siten_adminid_routen_para(request):
#     admin_id = request.GET.get('Admin_id', '')
#     site_name = request.GET.get('Site_Name', '')
#     route_name = request.GET.get('Route_Name', '')
#     start_date = request.GET.get('Start_Date', '')
#     end_date = request.GET.get('End_Date', '')
    
#     base_url = "http://127.0.0.1:65/VGT/Generate_Report_For_Sitename,AdminID,RouteName/"
#     print("para_baseurl:",base_url)
#     # Include parameters in the URL path
#     url_with_params = f"{base_url}?Admin_id={admin_id}&Site_Name={site_name}&Route_Name={route_name}&Start_Date={start_date}&End_Date={end_date}"
#     print('para:',url_with_params)
#     response = requests.get(url_with_params)
#     data = response.json()
    
#     return JsonResponse(data, safe=False)

# #@***************Update_Username_phone***************@
# '''@csrf_exempt
# def updateid_name_phone(request):
   
#     data = {}
#     if request.method == "PUT":  # Change the condition to check for DELETE method
#         json_data = json.loads(request.body.decode('utf-8'))
#         print("hello there")
#         data = {
#             "User_Name": json_data["User_Name"],  
#             "userID": json_data["userID"],
#             "Mobile": json_data['Mobile']
#         }
#         user_Name=data["User_Name"]
#         UserID=data["userID"]
#         mobile=data["Mobile"]
#         # print("jitesh",site_code,site_name)
#         URL = f"http://69.30.247.220:80:65/Update_userName_Phone/Update_userName_Phone/{user_Name},{UserID},{mobile}"
#         resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
#         print("output of r:", resp)
#         try:
#             paste_url = resp.text                      
#             return HttpResponse(paste_url)
#         except Exception as e:
#             print(resp.Status)
#     return JsonResponse({'success': False})'''     

@csrf_exempt
def update_idnamephone(request):
    # print("Request received")
    data = {}
    # URL = 'http://127.0.0.1:65/VGT/Update_userName_Phone/'      
    if request.method == "PUT":
        # to receive image data as JSON payload in the body of the request
        # we need to use request body
        json_data = json.loads(request.body.decode('utf-8'))
        data = {
            "User_Name": json_data["User_Name"],
            "userID": json_data["userID"],
            "Mobile": json_data["Mobile"]                              
        }    
        print("The data:",data)    
        # r = requests.put(url=URL, json=data)        
        # try:
        #     paste_url = r.text
        #     # print(r.status_code)
        #     print("The paste_url is: %s" % paste_url)
        #     return HttpResponse(paste_url)
        # except Exception as e:
        #     print(r.status_code)
        from vgtapp.models import Route_Management
        mycol1 = user_management
        mycol2 = Mapped_Route_Management
        mycol3 = Route_Management
        

        new_userName = data["User_Name"]
        new_Phone = data["Mobile"]
        uid = data["userID"]
        store_check_name = ''

        updated_field1_user_mgmt = {
                            "User_Name": new_userName,
                            "Mobile": new_Phone

                        }
        
        updated_field2_mapped_route_mgmt = {
                            "USER_NAME": new_userName
                        }
        
        updated_field3_route_mgmt = {
                            "User_Name": new_userName
                        }

        
        col1 = []
        '''--- updating user_management db ---'''
        mycol1.objects.filter(userID= uid).update(User_Name=new_userName,Mobile=new_Phone)
        for x in mycol1.objects.filter(userID= uid): 
            col1.append(x) 


        col2 = []
        '''--- updating mapped_route_management db ---'''
        mycol2.objects.filter(USER_NAME= store_check_name).update(USER_NAME = new_userName)
        for x in mycol2.objects.filter(USER_NAME = store_check_name):   
            col2.append(x)



        total_count = len(col1)+ len(col2)
        
        if total_count >0 :
            return {"Status":200,"Message": f'SUCCESSFULLY UPDATED!!'}
        else:
            return {"Status":500,"Message": f'Data Not Found'}
    return JsonResponse({'success': False})
 
 
# #@Giving Date,time & CameraName to get the recording value#
# global date,CameraName, time
 
# @csrf_exempt
# def getvideo_url(request):
#     if request.method == 'POST':
#         json_data = json.loads(request.body.decode('utf-8'))
#         global date, time, CameraName  # Update global variables
#         date = json_data['date']
#         time = json_data['time']
#         CameraName = json_data['CameraName']
#         print("Date:", date)
#         print("Time:", time)
#         print("CameraName:", CameraName)
#         # You might want to return a success response here
#         return JsonResponse({'message': 'Date, time, and camera name received'})
    
# #@***************Update_Site_Route_Camera***************@
# @csrf_exempt
# def vgt_update_siteroutecamera(request):
#     # print("Request received")
#     data = {}
#     URL = 'http://127.0.0.1:65/VGT/Update_Site_Route_Camera/'      
#     if request.method == "PUT":
#         # to receive image data as JSON payload in the body of the request
#         # we need to use request body
#         json_data = json.loads(request.body.decode('utf-8'))
#         data = {
            
#             "Admin_UserID": json_data["Admin_UserID"],
#             "Site_name": json_data["site_name"],            
#             "Route_Name": json_data["Route_Name"],
#             "Camera_Name": json_data["Camera_Name"]                                 
#         }        
#         r = requests.put(url=URL, json=data)        
#         try:
#             paste_url = r.text
#             # print(r.status_code)
#             print("The paste_url is: %s" % paste_url)
#             return HttpResponse(paste_url)
#         except Exception as e:
#             print(r.status_code)
#     return JsonResponse({'success': False})

# #@***************Update_Camera_question***************@
# @csrf_exempt
# def vgt_update_cameraquestion(request):   
#     data = {}
#     if request.method == "PUT":  
#         json_data = json.loads(request.body.decode('utf-8'))
#         print("hello there")
#         data = {
#             "Admin_UserID": json_data["Admin_UserID"],
#             "Site_Name": json_data["Site_Name"],
#             "Route_Name": json_data["Route_Name"],
#             "Camera_Name": json_data["Camera_Name"],            
#             "Add_check_query":json_data["Add_check_query"], 
#             "new_q":json_data["new_q"]
#         }
#         print("vgt_update_cameraquestion:",data)
#         admin_id=data["Admin_UserID"]
#         site_name=data["Site_Name"]
#         routen=data["Route_Name"]
#         cam_name=data["Camera_Name"]
#         check_q=data["Add_check_query"]
#         new_query=data["new_q"]
        

#         # print("jitesh",site_code,site_name)
        
#         URL = f"http://127.0.0.1:65/VGT_Update_Camera_question/{admin_id},{site_name},{routen},{cam_name},{check_q},{new_query}"
#         resp = requests.put(url=URL, json=data)  # Use requests.delete instead of requests.post
#         print("output of r:", resp)
#         try:
#             paste_url = resp.text                      
#             return HttpResponse(paste_url)
#         except Exception as e:
#             print(resp.Status)
#     return JsonResponse({'success': False}) 


# #************vgt_delete_question*************#
# @csrf_exempt
# def vgt_delete_question(request):
   
#     data = {}
#     if request.method == "DELETE":  # Change the condition to check for DELETE method
#         json_data = json.loads(request.body.decode('utf-8'))
#         print("hello there")
#         data = {
#             "Admin_id": json_data["Admin_id"],  
#             "Site_name": json_data["Site_name"],
#             "route_name": json_data["route_name"],            
#             "Camera_Name": json_data["Camera_Name"],
#             "Add_check_query": json_data["Add_check_query"]
#         }
#         print("vgt_delete_question:",data)
#         admin_id=data["Admin_id"]
#         site_name=data["Site_name"]
#         routen=data["route_name"]       
#         cam_name=data["Camera_Name"]
#         check_q=data["Add_check_query"]
#         # print("jitesh",site_code,site_name)
#         URL = f"http://127.0.0.1:65/VGT_Delete_Question/{admin_id},{site_name},{routen},{cam_name},{check_q}"
#         resp = requests.delete(url=URL, json=data)  # Use requests.delete instead of requests.post
#         print("output of r:", resp)
#         try:
#             paste_url = resp.text                      
#             return HttpResponse(paste_url)
#         except Exception as e:
#             print(resp.Status)
#     return JsonResponse({'success': False}) 

# #@***************get_vgt_alternate_live_feed***************@
def vgt_alternate_live_feed(request,Admin_ID):
    '''
    Live Feed for the given adminid.
    '''
    
    record = {}
    mycol = check_list
    mycol1 = site_management
    Camera_Name = []
    get_site_n = []
    get_route_n = []
    get_Q = []
    show_result = []
    #site = ""
    #route = ""
    #Get_Q = ""
    #Set_camera_name = ""
    
    for x in mycol.objects.filter(Admin_UserID = str(Admin_ID)):  
        print("The collection values are:",x)
        get_site_n.append(x.Site_Name) 
        site = list(set(get_site_n))
        get_route_n.append(x.Route_Name)
        route = list(set(get_route_n))
        get_Q.append(x.Add_check_query) 
        Get_Q = list(set(get_Q))
        adminID = Admin_ID
        Camera_Name.append(x.Camera_Name)
        Set_camera_name = list(set(Camera_Name))
        '''
        result = {
            "ADMIN_ID": str(adminID),
            "SITES": site,
            "ROUTES": route,
            "CHECK_LIST": get_Q
        }
        '''
    # print("site, route, Set_camera_name",site, route, Set_camera_name)
    for st, rt, camera_name in zip(get_site_n, get_route_n,Camera_Name):
       record = {"ADMIN_ID": str(adminID), "SITES": st, "ROUTES": rt,"Camera_Name":camera_name}
    show_result.append(record)
    
    return JsonResponse(show_result, safe=False)

# #@***************vgt_incident_report_adminID***************@
def vgt_incident_report_adminID(request,ADMIN_ID):
    '''
    Incident report for the given adminid.
    '''
    print("The admin id :",ADMIN_ID)
    # base_url = f"http://127.0.0.1:65/VGT_Incident_Report_Admin_ID/"    
    # url_with_site = f"{base_url}?ADMIN_ID={ADMIN_ID}"    
    # response = requests.get(url_with_site)
    # data = response.json() 
    
    list_of_checklist_data = []
    from vgtapp.models import Storing_Answers_To_Checklist
    stored_data = Storing_Answers_To_Checklist.objects.filter(Admin_id=ADMIN_ID)
    
    for data in stored_data:
        list_of_checklist_data.append({
            "Questions": data.Questions,
            "Answers": data.Answers,
            "Issues": data.Issues,
            "Description": data.Description,
            "Incident": data.Incident,
            "Code": data.Code,
            "Priority": data.Priority,
            "Site_Name": data.Site_Name,
            "Admin_id": data.Admin_id,
            "UserID": data.UserID,
            "User_name": data.User_name,
            "Route_Name": data.Route_Name,
            "camera_name": data.camera_name,
            "Schedule_time": data.Schedule_time,
            "End_time": data.End_time,
            "Imagestring": data.Imagestring,
            "Upload_photo_video_Image_string": data.Upload_photo_video_Image_string,
            "Registered_Camera_Answer_Response": data.Registered_Camera_Answer_Response
        })
    print("The checklist data:",list_of_checklist_data)
    return JsonResponse({"DATA":list_of_checklist_data,'success': False})

# #@***************vgt_patrolling_report_adminID***************@
def vgt_patrolling_report_adminID(request,ADMIN_ID):
    # base_url = f"http://127.0.0.1:65/VGT_Patrolling_Review_Admin_ID/"    
    # url_with_site = f"{base_url}?ADMIN_ID={ADMIN_ID}"    
    # response = requests.get(url_with_site)
    # data = response.json()  
    import ast
    from vgtapp.models import user_management,Mapped_Route_Management,Storing_Answers_To_Checklist
    mapRoute = Mapped_Route_Management
    userMgmt = user_management
    satc = Storing_Answers_To_Checklist
    
#     '''--- variables for Mapped_Route_Management'''
    store_user = []
    store_site = []
    store_route = []
    store_cam = []
    '''-- variable to store userID, collection user_management'''
    store_uid = []
    '''---variable to store camera names collection Store_Answer_To_Checklist ---'''
    check_cam = []
    '''--- other variables'''
    flattened_list1 = []
    main_record = []
    record = {}
    
    for x in mapRoute.objects.filter(Admin_UserID = str(ADMIN_ID)):
        store_user.append(x.USER_NAME)
        store_site.append(x.Site_Name)
        store_route.append(x.Route_Name)
        store_cam.append(x.Camera_Name)
    
    for uele in store_user:
        for x in userMgmt.objects.filter(Admin_UserID = str(ADMIN_ID), User_Name = str(uele)):
            store_uid.append(x.userID)
    # flattened_list1 = [item for sublist in store_cam for item in sublist]
    flattened_list1 = store_cam
    '''lets print:'''
    print("User Name", store_user)
    print("User ID",store_uid)
    print("Site Name",store_site)
    print("Route Name",store_route)
    print("Camera Name",flattened_list1)
    print("Cameradata",store_cam,len(store_cam))
    
    for user in store_user:
        index_of_user = store_user.index(user)
        get_route = store_route[index_of_user]
        get_site = store_site[index_of_user]
        get_camera = store_cam[index_of_user]
        get_uid = store_uid[index_of_user]
        count = len([docs for docs in satc.objects.filter(Admin_id = ADMIN_ID)]) 
        
        print("count records:", count)        
        if count > 0:
            print("Hi! in am inside if")
            for y in satc.objects.filter(Admin_id = ADMIN_ID, User_name = str(user)):
                temp = []
                temp.append(y.camera_name)
                print("print!",temp)
                record = {
                    "Admin_id": ADMIN_ID,
                    "User_Name": str(user),
                    "User_ID": get_uid,
                    "Site_Name": get_site,
                    "Route_Name": get_route,
                    "Camera_Name": temp,
                    "Status": "yes"
                }
                main_record.append(record)
        else:
            get_camera = ast.literal_eval(get_camera)
            record = {
                "Admin_id": ADMIN_ID,
                "User_Name": str(user),
                "User_ID": get_uid,
                "Site_Name": get_site,
                "Route_Name": get_route,
                "Camera_Name": get_camera,
                "Status": "no"
            }
            main_record.append(record)
    print("The main record:",main_record)    
    return JsonResponse(main_record, safe=False)

# #@***************vgt_user_incidentid_report_dashboard***************@
def vgt_user_incidentid_report_dashboard(request,USER_ID,SITE_NAME):
    # base_url = f"http://127.0.0.1:65/VGT_User_Incident_Report_UserDashboard/"    
    # url_with_site = f"{base_url}?USER_ID={USER_ID}&SITE_NAME={SITE_NAME}"    
    # response = requests.get(url_with_site)
    # data = response.json()   
    
    print("the user id and sitename :",USER_ID,SITE_NAME)
    print("USER_ID,SITE_NAME",type(USER_ID),type(SITE_NAME))
    import vgtapp.get_report4User as gr  
    
    gr.init_data()
    req = gr.get_incident_report4user(USER_ID,SITE_NAME) 
    print("The user incident data:",req)
    return JsonResponse({"data":req, "safe":False})
    # return JsonResponse(data, safe=False)

# #@***************vgt_get_user***************@
# def vgt_checkuser(request):
#     response= requests.get("http://127.0.0.1:65/VGT/VGT_Get_User/")
#     data = response.json()
#     print(type(data))
#     return JsonResponse(data, safe=False)


# # #@***************Reassigning_Incident***************@   
# # @csrf_exempt
# # def assign_incident(request):
# #     # print("Request received")
# #     data = {}
#     # URL = 'http://127.0.0.1:65/VGT/Reassigning_Incident/'      
# #     if request.method == "POST":
# #         # to receive image data as JSON payload in the body of the request
# #         # we need to use request body
# #         json_data = json.loads(request.body.decode('utf-8'))
# #         data = {
# #             "Admin_id": json_data["Admin_id"],        
# #             "User_Name":json_data["User_Name"],
# #             "User_id": json_data["User_id"],
# #             "Site_Name":json_data["Site_Name"],
# #             "Route_Name": json_data["Route_Name"],
# #             "Camera_Name": json_data["Camera_Name"],
# #             "Assigned_Incident": json_data["Assigned_Incident"],            
# #         }        
# #         r = requests.post(url=URL, json=data)        
# #         try:
# #             paste_url = r.text
# #             # print(r.status_code)
# #             print("The paste_url is: %s" % paste_url)
# #             return HttpResponse(paste_url)
# #         except Exception as e:
# #             print(r.status_code)
# #     return JsonResponse({'success': False})

# # #@***************vgt_get_info_livefeed***************@
# # '''def vgt_get_info_livefeed(request,Admin_ID):
# #     base_url = f"http://69.30.247.220:80:65/VGT_get_full_information_livefeed/"    
# #     url_with_site = f"{base_url}?Admin_ID={Admin_ID}"    
# #     response = requests.get(url_with_site)
# #     data = response.json()   
# #     return JsonResponse(data, safe=False)'''

# # #@***************vgt_ai_user_register***************@
# # @csrf_exempt
# # def AI_user_register(request):
# #     # print("Request received")
# #     data = {}
#     # URL = 'http://127.0.0.1:65/AI_Route_Registration/'
# #     if request.method == "POST":
# #         print("\n\n POST REQUEST RECEIVED! 😉\n\n")
# #         # to receive image data as JSON payload in the body of the request
# #         # we need to use request body
# #         json_data = json.loads(request.body.decode('utf-8'))
# #         data = {
# #             "Admin_id": json_data["Admin_id"],
# #             "Site_Name":  json_data["Site_Name"],
# #             "Route_Name": json_data["Route_Name"],                     
# #         }
# #         print('Admin_id:', data["Admin_id"])
# #         print('Site_Name:', data["Site_Name"])
# #         print('Route_Name:', data["Route_Name"])          
# #         r = requests.post(url=URL, json=data)
# #         print("output of r:", r)
# #         try:
# #             paste_url = r.text
# #             print(r.status_code)
# #             print("The paste_url is: %s" % paste_url)
# #             return HttpResponse(paste_url)
# #         except Exception as e:
# #             print("I am at exception!!")
# #             print(r.status_code)
# #     return JsonResponse({'success': False})

# # #@***************vgt_get_ai_route_management_info***************@
# # def get_ai_route_management_info(request):      
# #     response = requests.get('http://127.0.0.1:65/VGT/get_ai_route_management_info/')  
# #     print("API Response has been stored")  
# #     data = response.json()  
# #     print(type(data))
# #     print("Jitesh")    
# #     return JsonResponse(data, safe=False)

# # #@***************vgt_ai_checklist_register***************@
# # @csrf_exempt
# # def AI_checklist_register(request):
# #     # print("Request received")
# #     data = {}
#     # URL = 'http://127.0.0.1:65/AI_checkList_Registration/'
# #     if request.method == "POST":
# #         print("\n\n POST REQUEST RECEIVED! 😉\n\n")
# #         # to receive image data as JSON payload in the body of the request
# #         # we need to use request body
# #         json_data = json.loads(request.body.decode('utf-8'))
# #         data = {
# #             "Admin_id": json_data["Admin_id"],
# #             "Site_Name":  json_data["Site_Name"],
# #             "Site_Code": json_data["Site_Code"],
# #             "Route_Name": json_data["Route_Name"],
# #             "Camera_Name": json_data["Camera_Name"],
# #             "RTSP_link": json_data["RTSP_link"],
# #             "AI_Model": json_data["AI_Model"],                     
# #         }
# #         print('Admin_id:', data["Admin_id"])
# #         print('Site_Name:', data["Site_Name"])
# #         print('Site_Code:', data["Site_Code"])          
# #         r = requests.post(url=URL, json=data)
# #         print("output of r:", r)
# #         try:
# #             paste_url = r.text
# #             print(r.status_code)
# #             print("The paste_url is: %s" % paste_url)
# #             return HttpResponse(paste_url)
# #         except Exception as e:
# #             print("I am at exception!!")
# #             print(r.status_code)
# #     return JsonResponse({'success': False})


# # #@***************vgt_get_ai_checkList_info***************@
# # def get_ai_checkList_info(request):      
# #     response = requests.get('http://127.0.0.1:65/VGT/get_ai_checkList_info/')  
# #     print("API Response has been stored")  
# #     data = response.json()  
# #     print(type(data))
# #     print("Jitesh")    
# #     return JsonResponse(data, safe=False)


# # def get_video_Path(request):
# #     # Use the global variables to construct the video URL
# #     video_url = construct_video_url(date, time, CameraName)    
# #     # Return the constructed video URL
# #     return JsonResponse({'video_url': video_url})
 
# # def construct_video_url(date, time, cam_name):
# #     # Implement your logic here to construct the video URL
# #     # You can use the provided date, time, and cam_name to generate the URL
# #     # Example: http://your-server-url/videos/{date}/{time}/{cam_name}.mp4
# #     video_url = f"http://122.166.48.42:/Getting_video_url/?date={date}&time={time}&CameraName={cam_name}"
# #     print(video_url)
# #     return video_url

# # @csrf_exempt
# # def Person_Detection_Module(request):
# #     # print("Request received")
# #     data = {} 
#     # URL = 'http://127.0.0.1:65/Person_Detection_Module/'      
# #     if request.method == "POST":
# #         # to receive image data as JSON payload in the body of the request
# #         # we need to use request body
# #         json_data = json.loads(request.body.decode('utf-8'))
# #         data = {
# #             "url": json_data["url"],
# #             "Adminid": json_data["Adminid"],
# #             "Site_Name": json_data["Site_Name"],
# #             "Route_Name": json_data["Route_Name"],
# #             "Camera_Name": json_data["Camera_Name"],

# #         }       
# #         r = requests.post(url=URL, json=data)
# #         # print("output of r:", r)    
# #         try:
# #             paste_url = r.text
# #             # print(r.status_code)
# #             print("The paste_url is: %s" % paste_url)
# #             return HttpResponse(paste_url)
# #         except Exception as e:
# #             print(r.status_code)
# #     return JsonResponse({'success': False})
 

# # '''-----------------------------------'''
# # from django.shortcuts import render,redirect
# # from django.http import HttpResponse
# # from django.contrib.auth.models import User
# # from django.contrib.auth import authenticate,login
# # from django.contrib import messages



# # def Register_vegapp(request):
# #     print("You called line 1466!")
# #     if request.method=="POST":
# #         value  = request.POST
# #         print("The value:",value)
        
# #         # user = registration.objects.create(
# #         #         FirstName = 
# #         #         LastName = 
# #         #         Company_Name= 
# #         #         Department=
# #         #         Designation= 
# #         #         Phone= 
# #         #         Email= 
# #         #         Location= 
# #         # )
        
# #         # {
# #         #         FirstName: this.R_FirstName,
# #         #         LastName: this.R_LastName,
# #         #         Company_Name: this.R_Company_Name,
# #         #         Department: this.R_Department,
# #         #         Designation: this.R_Designation,
# #         #         Phone: this.R_Phone,
# #         #         Email: this.R_Email,
# #         #         Location: this.R_Location 
# #         #     }
        
# #         # first_name = request.POST.get('first_name')
# #         # last_name = request.POST.get('last_name')
# #         # Company_Name = request.POST.get('Company_Name')
# #         # Department = request.POST.get('Department')
# #         # Designation = request.POST.get('Designation')
# #         # Phone = request.POST.get('Phone')
# #         # Email = request.POST.get('Email')
# #         # Location = request.POST.get('Location')
# #         # user_data = User.objects.filter(first_name=first_name)
# #         # if user_data.exists():
# #         #     messages.info(request, "Username already created")
# #         #     return redirect('/Registration/')
        
# #         # user = User.objects.create(
# #         #     first_name = first_name,
# #         #     last_name = last_name,
# #         #     Company_Name = Company_Name,
# #         #     Department = Department,
# #         #     Designation= Designation
# #         # )
        
# #         # # user.set_password(password)
        
# #         # user.save()
# #         # messages.info(request, "Account Created Successfully.")
# #     return render (request,"Guardapp\Registration.html")