from datetime import datetime,timedelta


def takes_given_date_return_start_end_date():
    todays_date = datetime.now().date()#today's date
    startdate_of_this_week = todays_date - timedelta(days=todays_date.weekday()) #Start date of week for the given date
    seventh_date_of_the_week = (startdate_of_this_week + timedelta(days=7))#End date of the week
    return startdate_of_this_week.strftime("%d/%m/%Y") ,seventh_date_of_the_week.strftime("%d/%m/%Y")
