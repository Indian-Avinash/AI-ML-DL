'''----07.11.2023, Creating site management part. Collection named: site_management created.----'''

import pymongo
from datetime import datetime
from vgtapp.models import site_management,Camera_info
import urllib.parse
import vgtapp.get_update_site as gp

mycol = site_management
get_VGT_CameraInfo = Camera_info

store_Site_Name = []
store_Site_Code = []
count_of_users_list = []
global user_id_count


def site_management_info():
    '''get all information from the camera db'''
    temp_site_name = []
    temp_site_code = []  
    Admin_id = []
    
    mydoc = get_VGT_CameraInfo.objects.all()
    for x in mydoc:
        temp_site_name.append(x.Site_Name)
        temp_site_code.append(x.Site_Code)
        Admin_id.append(x.Admin_unique_id)

    # print(temp_site_name)
    # print(temp_site_code)
    '''--getting the unique values--'''
    unique_values_site_names = []
    [unique_values_site_names.append(x) for x in temp_site_name if x not in unique_values_site_names]


    unique_values_site_codes = []
    [unique_values_site_codes.append(x) for x in temp_site_code if x not in unique_values_site_codes]   
    

    '''----with each unique site_names extracting relevant data from the db---'''
    
    for site in unique_values_site_names:
        s_name = site
        temp = []
        for x in get_VGT_CameraInfo.objects.filter(Site_Name = s_name):
            
            s_n = s_name
            data_found_for_that_site = get_VGT_CameraInfo.objects.filter(Site_Name = s_name)

            '''
            Getting the count of cameras in that particulear site.
            '''

            # print("I am at the line 50:",camera_total_count,s_n)
            s_cd = x.Site_Code
            re = x.Region
            ct = x.City
            camera = x.CameraName

            camera_count = x.Site_Camera_Count
            

        '''------08.11.2023-----'''
        total_camera_objects = get_VGT_CameraInfo.objects.filter(Site_Name = s_name)
        list_of_cameras_in_camerainfo = [values for values in total_camera_objects] 
        count_of_cameras = len(list_of_cameras_in_camerainfo)
        
        # total_count = site_registration.objects.all()

        if count_of_cameras == 0:
            
            info = {
                    "Site_Name": s_n,
                    "Site_Code": s_cd,
                    "Region": re,
                    "Branch": ct,
                    "No_Route": 0,
                    "is_action": 1,
                    "No_Of_Camera": 0,
                }
            
            mycol.objects.create(
                    Site_Name= s_n,
                    Site_Code= s_cd,
                    Region= re,
                    Branch= ct,
                    No_Route= 0,
                    is_action= 1,
                    No_Of_Camera= 0,
            )  
            gp.site_management_camera_update()      # updating the db        
            #init_data()
        else:
            print("I am ate 81!")
            mydoc1 = mycol.objects.all()
            for x in mydoc1:
                store_Site_Name.append(x.Site_Name)
                store_Site_Code.append(x.Site_Code)
                
            # Get the elements that are in unique_values_site_names but not in store_Site_Name
            elements_not_in_common = set(unique_values_site_names) - set(store_Site_Name)
            element = sorted(elements_not_in_common)   # changing to list from set
            # print(element)
            
            # Check if there are elements not in common
            for site in element:
                s_name = site

                # print("I am at the line 91:",camera_total_count)
                temp = []
                for x in get_VGT_CameraInfo.objects.filter(Site_Name = s_name):
                    
                    # latest_user_id_count += 1
                    # print("The latest count is:",latest_user_id_count)
                    s_n = s_name
                    data_found_for_that_site = get_VGT_CameraInfo.objects.filter(Site_Name = s_n)

                    s_cd = x.Site_Code
                    re = x.Region
                    ct = x.City
                    camera = x.CameraName
                    camera_count = x.Site_Camera_Count
                    temp.append(camera_count)
                    # c_no = max(temp)
                # print("camera_total_count:",camera_total_count)
                #cam_count = len(temp) 
                       
                mycol.objects.create(
                    Site_Name= s_n,
                    Site_Code= s_cd,
                    Region= re,
                    Branch= ct,
                    No_Route= 0,
                    is_action= 1,
                    No_Of_Camera= len([values for values in data_found_for_that_site])
                )
                gp.site_management_camera_update()      # updating the db
                
                
                
            
#site_management_info()
#get_camera_count_update()
