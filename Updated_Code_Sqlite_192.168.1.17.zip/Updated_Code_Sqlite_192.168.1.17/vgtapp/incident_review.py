'''---01.02.2024, code that will create a new collection named: Incident_Review,
a new user(Patroller) will be assigned an existing incident ---'''

import pymongo
from datetime import datetime
from vgtapp.models import VGT_assign_incident

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["Guard_Patrol"]  
mycol = mydb["Incident_Review"]

def assign_old_incident(userdata):
    get_admin = userdata["Admin_id"]
    get_user = userdata["User_Name"]
    get_uid = userdata["User_id"]
    get_route = userdata["Route_Name"]
    get_site = userdata["Site_Name"]
    get_cam = userdata["Camera_Name"]
    get_inci = userdata["Assigned_Incident"]

    show_result = {
        "Admin_id": get_admin,
        "User_Name": get_user,
        "User_id": get_uid,
        "Site_Name": get_site,
        "Route_Name": get_route,
        "Camera_Name": get_cam,
        "Assigned_Incident": get_inci,
        "Status": "yes",
        "Date_Of_ReAssignment": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
        }
    
    assigned_incident =  VGT_assign_incident.objects.create(
            Admin_id = show_result["Admin_id"],
            User_Name= show_result["User_Name"], 
            User_id = show_result["User_id"],
            Site_Name= show_result["Site_Name"],
            Route_Name= show_result["Route_Name"],
            Camera_Name= show_result["Camera_Name"],
            Assigned_Incident= show_result["Assigned_Incident"],
    )
    assigned_incident.save()
           
    show = {
        "statusCode": 200,
        "statusMessage": "INCIDENT SUCCESSFULLY RE-ASSIGNED!"        
        }
    
    return show
