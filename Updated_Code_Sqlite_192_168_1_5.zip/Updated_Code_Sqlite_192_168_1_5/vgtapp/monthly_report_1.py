'''----
program takes the Admin_Id and Registered_Camera_Answer_Response, from there calculate the month 
and store in another collection named monthly_weekly_incident
02.02.2024
-----'''

import pymongo
from datetime import datetime
from vgtapp.models import *

# refercol = Storing_Answers_To_Checklist
refercol = check_list
mycol = monthly_weekly_incident

admin_id_list = []
Incident_list = []
priority_list = []
date_incident_list = []

'''----initializing the DB--------'''
def init_data():
    mydoc = refercol.objects.all()
    admin_id_list.clear()
    # Incident_list.clear()
    # priority_list.clear()  
    date_incident_list.clear()
    for x in mydoc:
        
        admin_id_list.append(x.Admin_UserID)
        # Incident_list.append(x.Incident)
        # priority_list.append(x.Priority)
        date_incident_list.append(x.DateofCameraRegistration_DateFormat)


'''---getting the related information for month,year and week ----'''
def get_date_info(date):
    # date_str = str(date)  # Assuming the format is DD/MM/YYYY

    # Convert string to datetime object
    # date = datetime.strptime(date_str, "%d/%m/%Y")
    d,m,y = date.split("/")
    # print("The d , m ,y is:",[d,m,y])
    # Extract month abbreviation (e.g., Jan)
    # month = date.strftime("%b")
    day = int(d)
    month = m
    # Extract year
    # year = date.strftime("%Y")
    year = y
    # Calculate which week of the month
    week = (day - 1) // 7 + 1
    week = "first" if week == 1 else "second" if week == 2 else "third" if week == 3 else "fourth" if week == 4 else "fifth"

    # print("Month:", month)
    # print("Year:", year)
    # print("Week:", week + " week")
    print("month,year,week",[month,year,week])
    return month,year,week



def information():
    print("I am at the information function!")
    try:
        '''--- get the required data from the collection named: Storing_Answers_To_Checklist---'''
        adminId = ''
        incident_happen = ''
        incident_priority = ''
        date = ''
        mydoc = refercol.objects.all()
        for x in mydoc:
            # print("adminid's:",x.Admin_id)
            # print("The docs are:",x)
            #admin_id_list.append(x['Admin_UserID'])
            adminId = x.Admin_UserID
            #Incident_list.append(x['Incident'])
            incident_happen = x.Add_check_query
            
            #priority_list.append(x['Priority'])
            # incident_priority = x.Priority
            #date_incident_list.append(x['Registered_Camera_Answer_Response'])
            date = x.DateofCameraRegistration_DateFormat
            print("The registered date's are:",date)
            if date != "0" and incident_happen != "":
                # print("The date is:",date)
                m,y,w = get_date_info(date)

                info = {
                    "Admin_UserID": adminId,
                    "Incident_Happened": incident_happen,
                    # "Incident_Priority": incident_priority,
                    "Incident_Month": m,
                    "Incident_Week": w,
                    "Incident_Year": y
                }
                # print("The monthly report:",info)
                info_data = mycol.objects.create(
                    Admin_UserID = info["Admin_UserID"],
                    Incident_Happened = info["Incident_Happened"],
                    # Incident_Priority = info["Incident_Priority"],
                    Incident_Month = info["Incident_Month"],
                    Incident_Week = info["Incident_Week"],
                    Incident_Year = info["Incident_Year"]
                )
                
                info_data.save()
            else:
                print("Incorrect data")
    except Exception as e:
        print("error",e)
