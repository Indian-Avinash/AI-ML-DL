# import json
# import os
# from vgtapp import ipconfig

# # views_file_path = 'D:/Update_VGT_Project/GPatrol/Guardtour/Guardapp/views.py'
# list_dir = os.listdir("C:/Users/KFT_1069/Downloads/Updated_Code_Sqlite 1/vgtapp/templates_Copy")
# for htmls in list_dir:
#     print("The html:",htmls)
    

# class change_file_name():
    
#     def __init__(self,views_file_path,folder_path):
#         '''
#         Assinging the variables for file path 
#         '''
#         self.views_file_path = views_file_path 
#         self.folder_path = folder_path
        
   
#     # Define a function to update URLs in the views file
#     def update_urls_in_file(self):
#         #print("Folder path :",self.folder_path)
#         os.chdir(self.folder_path)
#         updated_lines = []
#         with open(self.views_file_path, 'r', encoding='utf-8') as views_file:  # Specify 'utf-8' encoding here
#             print("The file path is:",self.views_file_path)
#             for line in views_file:
#                 print("The line",line)
#                 # Iterate through each line and update URLs
#                 ip_address = ipconfig.get_ipconfig()
#                 dicts = {"http://127.0.0.1:8000":f"http://{ip_address}:8000"}
#                 # dicts = {"http://192.168.1.10:8000":f"http://127.0.0.1:8000"}
#                 for old_url, new_url in dicts.items():
#                     line = line.replace(old_url, new_url)
#                 updated_lines.append(line)


#         # Write the updated content back to the views file
#         with open(self.views_file_path, 'w', encoding='utf-8') as views_file:  # Specify 'utf-8' encoding here
#             views_file.writelines(updated_lines)

# for htmls in list_dir:
#     folder_path = "C:/Users/KFT_1069/Downloads/Updated_Code_Sqlite 1/vgtapp/templates_Copy"
#     object = change_file_name(htmls,folder_path)
#     object.update_urls_in_file()