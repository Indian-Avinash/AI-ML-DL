import smtplib
import random
import pymongo
# import models as mdls
from vgtapp.models import admin
from pymongo import MongoClient #mongo and db
from email.message import EmailMessage #Basic message object for the email package object model.


mycol = admin
stored_email = []


def email_alert(emaildata):
    
    """_summary_
    Sending the email to the client using the smtplib and email.message
    """

    # print("Started the Email Generation!")
    # name = str(email_name)
    to = str(emaildata)
    # print(type(to))
    msg = EmailMessage() #calling the function
    verfication_code_random_number = random.randint(1000, 999999) #to print a random number between 1000 and 9999
    #msg.set_content(f"{random_number}") #body text
    mail_content = '''
                Dear Customer,
                I hope this message finds you well. We are thrilled to welcome you to Knowledgeflex and appreciate the opportunity to serve you. As we kick off this partnership, we wanted to provide you with the necessary information to access our dashboard.
                    
                Your Verfication Code is vefication_code
                
                                
                Best Regards,
                Knowledgeflex Team [Contact Information]'''
                
    # Replace "Customer" with the extracted first name
    modified_mail_content = mail_content.replace("Customer", to)
    modified_mail_content = mail_content.replace("vefication_code", str(verfication_code_random_number))
    msg.set_content(f"{modified_mail_content}") #body text
  

    msg['subject'] = "Welcome to Knowledgeflex - Your Login Credentials Inside!" #subject of the email
    msg['to'] = to #to address 
 
    # print("Defined the subject and to address!")
    mydoc = mycol.objects.all()# getting all the records from the db
    # print(mydoc)
    for x in mydoc:
        stored_email.append(x.Email)
        
    # print(stored_email)
    # print("To address",to)

    if emaildata in stored_email:
        # print("Success")
        server = smtplib.SMTP("smtp.gmail.com",587)
        # server = smtplib.SMTP("smtp.office365.com",587)
        server.starttls()
        # print("login!") 
        server.login("kftaiblr@gmail.com", "falmmxkqyxmnttbo")
        server.send_message(msg)
        # print("Email Sent!!")
        server.quit()
        # print("Password is correct.")
        success = {
                "statusCode":  200,
                "message": "Sucessful Login",
                "Verification_Code" : verfication_code_random_number              
            }

        return success

    else:                                           # In case user provided wrong email id which is not registered.

        email_not_found = {

                "statusCode":  500,
                "message": "Login Denied, E-mail Not-FOUND",
                "username": "Unknown"

            }

        return email_not_found


