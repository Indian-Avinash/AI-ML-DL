from vgtapp import get_start_end_date
# import pymongo
from datetime import datetime,timedelta
from vgtapp.models import *

# mongoclient = pymongo.MongoClient("mongodb://localhost:27017/")

mydb = Storing_Answers_To_Checklist
total_task = Mapped_Route_Management
user_database = user_management

def completed_pending_report(adminid):
    print(f"The weekly report for the given adminid {adminid} ")
    '''
    For the given admin id generating the weekly completed,pending,total tasks.
    '''
    adminid = adminid.split("=")[1]
    storage_of_adminids = []
    storage_of_answered_question_count_list = []
    startdate_of_week, enddate_of_week = get_start_end_date.takes_given_date_return_start_end_date()
    # print("The startdate and enddate:",startdate_of_week,enddate_of_week,type(startdate_of_week),type(enddate_of_week))
    
    
    for dictionary in user_database.objects.filter(Admin_UserID = adminid):
        storage_of_adminids.append(dictionary.Admin_UserID)
        
    
    # print('Total userids are:',storage_of_adminids)
    
    start_date_list = startdate_of_week.split("/")
    start_day,start_month,start_year =int(start_date_list[0]),int(start_date_list[1]),int(start_date_list[2])
    
    End_date_list = enddate_of_week.split("/")
    End_day,End_month,End_year =int(End_date_list[0]),int(End_date_list[1]),int(End_date_list[2])
    
    # Define start and end dates   
    start_date = datetime(start_year, start_month, start_day)
    end_date = datetime(End_year, End_month, End_day)

    date_difference = end_date - start_date
    # Generate a list of dates within the range
    date_list = [(start_date + timedelta(days=x)).strftime("%d/%m/%Y") for x in range(date_difference.days + 1)]


    for adminid in set(storage_of_adminids):
        for date in date_list:
            for dicts in mydb.objects.filter(Admin_id=int(adminid),Registered_Camera_Answer_Response=date):
                storage_of_answered_question_count_list.append(dicts)
                
    count_of_tasks_for_that_weeks = []
    for adminid in set(storage_of_adminids):
        for date in date_list:
            for dicts in total_task.objects.filter(Admin_UserID=adminid,DateOfCameraRegistration_Dateformat=date):
                #print("The admin id and the dates are:",dicts["Admin_UserID"],dicts["DateOfCameraRegistration_Dateformat"])
                count_of_tasks_for_that_weeks.append(dicts)
    
    count_of_answered_Question_for_that_week =  len(storage_of_answered_question_count_list)   
    count_of_tasks = len(count_of_tasks_for_that_weeks)
    
    return_data = {"Total_Tasks":count_of_tasks,
                    "Completed_Tasks":count_of_answered_Question_for_that_week,
                    "Pending_Tasks":count_of_tasks-count_of_answered_Question_for_that_week}
    
    return return_data