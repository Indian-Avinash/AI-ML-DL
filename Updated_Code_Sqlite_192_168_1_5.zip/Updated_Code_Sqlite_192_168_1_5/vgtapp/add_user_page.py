'''--- Creating user management, collection named: user_management, 30.11.2023 (modified one) 
here it has been assumed that user being added by the admin------'''
import pymongo
from datetime import datetime
from vgtapp.models import user_management


# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["Guard_Patrol"]
mycol = user_management

store_name = []
store_mobile = []
dt = []
Id = []

'''----initializing the DB--------'''
def init_data():
    mydoc = mycol.objects.all()
    store_name.clear()
    store_mobile.clear()
    store_name.clear()  
    for x in mydoc:
        store_name.append(x.User_Name)
        store_mobile.append(x.Mobile)


def add_user_page(data):
    username = data["First_Name"] + ' ' + data["Last_Name"]
    get_name = username
    get_site = data["Site_Name"]
    get_code = data["Site_Code"]
    get_Designation = data["Designation"]
    get_ph = data["Mobile"]
    get_email = data["Email"]
    admin_userid = data["Admin_UserID"]
    #check whether the user is registered or not, if registered then get all info from registered employee db
    # restrict any duplicate entry, of adding user by admin.

    # check for any record present in the db:
    row_count = len([docs for docs in mycol.objects.all()])
    # print(row_count)
    if row_count != 0:
        for x in mycol.objects.all():
            u_n = x.User_Name
            store_name.append(u_n)
            ph = x.Mobile
            store_mobile.append(ph)
            date = x.Date_Registration
            dt.append(date)
            u_id = x.userID
            Id.append(u_id)
            
        user_id = max(Id) + 1
        if get_name in store_name and get_ph in store_mobile:
            index = store_mobile.index(get_ph)            
            rg_dt = dt[index]
            show = {
                    "Status":500,
                    "message": "REGISTRATION DENIED!! USER ALREADY REGISTERED",                    
                    "RegisteredDate": rg_dt                
                }
            return show
        else:
            # insert_info = {
            #                 "User_Name":get_name,
            #                 "userID": user_id,
            #                 "Site_Name": get_site,
            #                 "Site_Code": get_code,        
            #                 "Designation": get_Designation,
            #                 "Mobile": get_ph,
            #                 "Email": get_email,  
            #                 "Admin_UserID": admin_userid,
            #                 "Password": "7777",
            #                 "Date_Registration": datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
            #             }
            userdata = mycol.objects.create(
                User_Name = get_name,
                userID =  user_id,
                Site_Name =  get_site,
                Site_Code =  get_code,        
                Designation =  get_Designation,
                Mobile =  get_ph,
                Email =  get_email,  
                Admin_UserID =  admin_userid,
                Password =  "7777",
                Date_Registration =  datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
 
                )
            userdata.save()
            show = {
                    "Status":200,
                    "message": "USER ADDED SUCCESSFULLY!!",
                    "username": get_name,
                }
            return show
    else:
        user_id = 1
        # insert_info = {
        #                 "User_Name":get_name,
        #                 "userID": user_id,
        #                 "Site_Name": get_site,
        #                 "Site_Code": get_code,        
        #                 "Designation": get_Designation,
        #                 "Mobile": get_ph,
        #                 "Email": get_email,  
        #                 "Admin_UserID": admin_userid,
        #                 "Password": "7777",      
        #                 "Date_Registration": datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
        #             }
        userdata = mycol.objects.create(
                User_Name = get_name,
                userID =  user_id,
                Site_Name =  get_site,
                Site_Code =  get_code,        
                Designation =  get_Designation,
                Mobile =  get_ph,
                Email =  get_email,  
                Admin_UserID =  admin_userid,
                Password =  "7777",
                Date_Registration =  datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
 
                )
        userdata.save()
        # mycol.insert_one(insert_info)  
        show = {
                "Status":200,
                "message": "USER ADDED SUCCESSFULLY!!",
                "username": get_name,
            }
        return show
